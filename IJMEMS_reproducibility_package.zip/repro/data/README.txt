Place KDDTrain.txt, KDDTest.txt, UNSW_NB15_training-set.csv and UNSW_NB15_testing-set.csv here (see README).
