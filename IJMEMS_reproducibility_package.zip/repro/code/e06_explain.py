"""E06: explanation analysis with expected-gradients SHAP on the logit margin.
(a) agreement with shap.GradientExplainer, (b) completeness / Monte-Carlo convergence,
(c) explanation shift under PGD with paired permutation test and class-wise (two-sided) view,
(d) stability of global importance across training seeds.  usage: python3 e06_explain.py nsl|unsw"""
import sys, time, numpy as np, torch, shap
from scipy import stats
from nidslib import *
SMOKE = os.environ.get("SMOKE") == "1"
NS = (lambda full, small: small if SMOKE else full)

ds = sys.argv[1]
D = load(ds)
Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
d = Xtr.shape[1]; names = D["meta"]["feature_names"]
base = load_model(f"{ds}_base_s42", d); rob = load_model(f"{ds}_pgdat_s42", d)
B = Xtr[stratified_idx(ytr, 1000, seed=21)]
res = {"dataset": ds}; arr = {}
t0 = time.time()

# (a) agreement with the reference implementation
ia = stratified_idx(yte, NS(300, 40), seed=31); Xa = Xte[ia]
agree = {}
for K in NS((200, 1000), (20,)):
    np.random.seed(0)
    expl = shap.GradientExplainer(base, torch.tensor(B))
    sv = np.array(expl.shap_values(torch.tensor(Xa), nsamples=K, rseed=123))
    if sv.ndim == 3 and sv.shape[-1] == 2:
        ref = sv[:, :, 1] - sv[:, :, 0]
    else:
        ref = sv[1] - sv[0]
    ours = eg_attrib(base, Xa, B, K=K, seed=K)
    r_ps = [stats.pearsonr(ref[i], ours[i])[0] for i in range(len(Xa)) if ref[i].std() > 0 and ours[i].std() > 0]
    gi = stats.pearsonr(np.abs(ref).mean(0), np.abs(ours).mean(0))[0]
    agree[str(K)] = dict(median_per_sample_pearson=float(np.median(r_ps)), p10_per_sample_pearson=float(np.percentile(r_ps, 10)),
                         global_importance_pearson=float(gi))
    print(f"[{ds}] agreement K={K}: {agree[str(K)]} ({time.time()-t0:.0f}s)", flush=True)
res["agreement_with_shap"] = agree

# (b) completeness and convergence
ic = stratified_idx(yte, NS(500, 50), seed=41); Xc = Xte[ic]
target_sum = margin_np(base, Xc) - margin_np(base, B).mean()
conv = []
for K in NS((10, 20, 50, 100, 200, 500, 1000, 2000), (10, 20, 50)):
    phi = eg_attrib(base, Xc, B, K=K, seed=K)
    resid = phi.sum(1) - target_sum
    conv.append(dict(K=K, rmse=float(np.sqrt(np.mean(resid ** 2))),
                     rel_rmse=float(np.sqrt(np.mean(resid ** 2)) / target_sum.std())))
lk = np.log([c["K"] for c in conv]); lr = np.log([c["rmse"] for c in conv])
slope = float(np.polyfit(lk, lr, 1)[0])
reps = np.stack([eg_attrib(base, Xc[:200], B, K=200, seed=900 + s) for s in range(5)])
noise = float(np.median(reps.std(0).sum(1) / np.maximum(np.abs(reps.mean(0)).sum(1), 1e-12)))
res["convergence"] = dict(points=conv, loglog_slope=slope, rel_noise_K200=noise)
print(f"[{ds}] convergence slope={slope:.3f} rel_noise@200={noise:.4f} {conv}", flush=True)

# (c) explanation shift under PGD (eps=0.1), both models
i3 = stratified_idx(yte, NS(3000, 200), seed=51); X3, y3 = Xte[i3], yte[i3]
shift = {}
for tag, m in (("base", base), ("robust", rob)):
    xa = pgd(m, X3, y3, 0.1, mask)
    pc, pa = predict(m, X3), predict(m, xa)
    fc = eg_attrib(m, X3, B, K=200, seed=7); fa = eg_attrib(m, xa, B, K=200, seed=8)
    gc, ga = np.abs(fc).mean(0), np.abs(fa).mean(0)
    L1 = float(np.abs(gc - ga).sum())
    rng = np.random.default_rng(99); perm = np.empty(NS(2000, 20))
    for p in range(len(perm)):
        sw = rng.random(len(X3)) < 0.5
        A = np.where(sw[:, None], fa, fc); Bm = np.where(sw[:, None], fc, fa)
        perm[p] = np.abs(np.abs(A).mean(0) - np.abs(Bm).mean(0)).sum()
    pval = float((1 + (perm >= L1).sum()) / (len(perm) + 1))
    per = np.abs(fc - fa).sum(1)
    rho = np.array([stats.spearmanr(np.abs(fc[i]), np.abs(fa[i])).correlation for i in range(len(X3))])
    top = lambda v: set(np.argsort(-np.abs(v))[:10])
    jac = np.array([len(top(fc[i]) & top(fa[i])) / len(top(fc[i]) | top(fa[i])) for i in range(len(X3))])
    dm = margin_np(m, xa) - margin_np(m, X3)
    comp = stats.pearsonr((fa - fc).sum(1), dm)[0]
    cls = {}
    for c, cn in ((0, "normal"), (1, "attack")):
        s = y3 == c
        cls[cn] = dict(L1=float(np.abs(np.abs(fc[s]).mean(0) - np.abs(fa[s]).mean(0)).sum()),
                       mean_margin_change=float(dm[s].mean()), flipped=float((pc[s] != pa[s]).mean()),
                       median_rho=float(np.nanmedian(rho[s])))
        arr[f"{tag}_signed_clean_{cn}"] = fc[s].mean(0); arr[f"{tag}_signed_adv_{cn}"] = fa[s].mean(0)
    order = np.argsort(-gc)
    shift[tag] = dict(L1=L1, rel_L1=float(L1 / gc.sum()), perm_p=pval, perm_max=float(perm.max()),
                      per_sample_L1_median=float(np.median(per)), per_sample_L1_iqr=[float(np.percentile(per, 25)), float(np.percentile(per, 75))],
                      median_rank_rho=float(np.nanmedian(rho)), mean_top10_jaccard=float(jac.mean()),
                      completeness_corr_shift_vs_margin_change=float(comp), by_class=cls,
                      top15=[(names[j], float(gc[j]), float(ga[j])) for j in order[:15]])
    arr[f"{tag}_gc"] = gc; arr[f"{tag}_ga"] = ga
    print(f"[{ds}] shift {tag}: L1={L1:.3f} rel={L1/gc.sum():.3f} p={pval:.4g} rho={np.nanmedian(rho):.3f} "
          f"jac={jac.mean():.3f} comp={comp:.4f} cls={cls} ({time.time()-t0:.0f}s)", flush=True)
res["shift"] = shift

# (d) stability of global importance across training seeds
i1 = stratified_idx(yte, NS(1000, 100), seed=61); X1 = Xte[i1]
G = {}
for s in SEEDS:
    nm = f"{ds}_base_s{s}"
    if model_exists(nm):
        G[s] = np.abs(eg_attrib(load_model(nm, d), X1, B, K=200, seed=s)).mean(0)
taus, jacs = [], []
ks = list(G)
for a in range(len(ks)):
    for b in range(a + 1, len(ks)):
        taus.append(stats.kendalltau(G[ks[a]], G[ks[b]]).correlation)
        ta, tb = set(np.argsort(-G[ks[a]])[:10]), set(np.argsort(-G[ks[b]])[:10])
        jacs.append(len(ta & tb) / len(ta | tb))
res["seed_stability"] = dict(n_models=len(ks), mean_kendall_tau=float(np.mean(taus)) if taus else None,
                             mean_top10_jaccard=float(np.mean(jacs)) if jacs else None)
print(f"[{ds}] seed stability: {res['seed_stability']}", flush=True)
sfx = "_smoke" if SMOKE else ""
np.savez_compressed(os.path.join(RES, f"e06_{ds}_arrays{sfx}.npz"), **arr)
save_json(res, f"e06_{ds}_explain{sfx}.json")
print("done", round(time.time() - t0), "s")
