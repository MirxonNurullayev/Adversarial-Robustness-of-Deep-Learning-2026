"""E03: multi-seed training (baseline + PGD-AT) and two-sided robustness evaluation.
usage: python3 e03_multiseed.py nsl|unsw"""
import sys, time, numpy as np
from nidslib import *

ds = sys.argv[1]
D = load(ds)
Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
d = Xtr.shape[1]
res = {"dataset": ds, "seeds": SEEDS, "eps": EPS_GRID, "runs": {}}
t0 = time.time()
for seed in SEEDS:
    run = {}
    models = {}
    for kind in ("base", "pgdat"):
        nm = f"{ds}_{kind}_s{seed}"
        if model_exists(nm):
            models[kind] = load_model(nm, d)
        else:
            tt = time.time()
            models[kind] = (train_standard(Xtr, ytr, seed, tag=f"{ds}-base") if kind == "base"
                            else train_robust(Xtr, ytr, mask, seed, "pgdat", eps=0.1, tag=f"{ds}-pgdat"))
            save_model(models[kind], nm)
            run[f"{kind}_train_seconds"] = time.time() - tt
    preds = {}
    for kind, m in models.items():
        pc = predict(m, Xte); preds[kind] = pc
        z = margin_np(m, Xte)
        from sklearn.metrics import roc_auc_score
        r = {"clean": rates(yte, pc), "clean_auc": float(roc_auc_score(yte, z)), "fgsm": {}, "pgd": {}}
        if seed == 42:
            r["clean_ci"] = {k: bootstrap_ci(yte, pc, f) for k, f in (
                ("acc", lambda a, b: (a == b).mean()),
                ("tpr", lambda a, b: (b[a == 1] == 1).mean()),
                ("fpr", lambda a, b: (b[a == 0] == 1).mean()))}
        for e in EPS_GRID:
            r["fgsm"][str(e)] = two_sided(yte, pc, predict(m, fgsm(m, Xte, yte, e, mask)))
            r["pgd"][str(e)] = two_sided(yte, pc, predict(m, pgd(m, Xte, yte, e, mask, chunk=30000)))
        run[kind] = r
        print(f"[{ds} seed={seed} {kind}] clean acc={r['clean']['acc']:.4f} tpr={r['clean']['tpr']:.4f} "
              f"fpr={r['clean']['fpr']:.4f} | PGD0.1 acc={r['pgd']['0.1']['acc']:.4f} tpr={r['pgd']['0.1']['tpr']:.4f} "
              f"fpr={r['pgd']['0.1']['fpr']:.4f} | PGD0.3 acc={r['pgd']['0.3']['acc']:.4f}  ({time.time()-t0:.0f}s)", flush=True)
    run["mcnemar_clean_base_vs_pgdat"] = mcnemar(yte, preds["base"], preds["pgdat"])
    res["runs"][str(seed)] = run
    save_json(res, f"e03_{ds}_multiseed.json")
print("done", round(time.time() - t0), "s")
