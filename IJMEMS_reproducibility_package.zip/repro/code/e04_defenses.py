"""E04: defence comparison and robustness-accuracy frontier (seed 42).
PGD-AT with several training budgets, TRADES (beta sweep) and MART, all with the same
masked 7-step inner maximisation.  usage: python3 e04_defenses.py nsl|unsw [quick]"""
import sys, time, numpy as np
from sklearn.metrics import roc_auc_score
from nidslib import *

ds = sys.argv[1]; quick = len(sys.argv) > 2
D = load(ds)
Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
d = Xtr.shape[1]; SEED = 42
configs = [("base", "base", None, None), ("pgdat_e0.1", "pgdat", 0.1, None)]
if quick:
    configs += [("pgdat_e0.05", "pgdat", 0.05, None), ("pgdat_e0.2", "pgdat", 0.2, None),
                ("trades_b6", "trades", 0.1, 6.0), ("mart_b6", "mart", 0.1, 6.0)]
else:
    configs += [("pgdat_e0.02", "pgdat", 0.02, None), ("pgdat_e0.05", "pgdat", 0.05, None),
                ("pgdat_e0.2", "pgdat", 0.2, None), ("pgdat_e0.3", "pgdat", 0.3, None),
                ("trades_b1", "trades", 0.1, 1.0), ("trades_b3", "trades", 0.1, 3.0),
                ("trades_b6", "trades", 0.1, 6.0), ("mart_b6", "mart", 0.1, 6.0)]
res = {"dataset": ds, "seed": SEED, "models": {}}
t0 = time.time()
for key, method, eps, beta in configs:
    nm = {"base": f"{ds}_base_s42", "pgdat_e0.1": f"{ds}_pgdat_s42"}.get(key, f"{ds}_{key}_s42")
    if model_exists(nm):
        m = load_model(nm, d); secs = None
    else:
        tt = time.time()
        m = train_robust(Xtr, ytr, mask, SEED, method, eps=eps, beta=beta if beta else 6.0, tag=f"{ds}-{key}")
        save_model(m, nm); secs = time.time() - tt
    pc = predict(m, Xte)
    r = {"method": method, "eps_train": eps, "beta": beta, "train_seconds": secs,
         "clean": rates(yte, pc), "clean_auc": float(roc_auc_score(yte, margin_np(m, Xte))), "pgd": {}}
    for e in (0.05, 0.1, 0.2, 0.3):
        r["pgd"][str(e)] = two_sided(yte, pc, predict(m, pgd(m, Xte, yte, e, mask, chunk=30000)))
    res["models"][key] = r
    print(f"[{ds}] {key:12s} clean acc={r['clean']['acc']:.4f} fpr={r['clean']['fpr']:.4f} tpr={r['clean']['tpr']:.4f} | "
          f"PGD0.1 acc={r['pgd']['0.1']['acc']:.4f} PGD0.3 acc={r['pgd']['0.3']['acc']:.4f} ({time.time()-t0:.0f}s)", flush=True)
    save_json(res, f"e04_{ds}_defenses.json")
print("done", round(time.time() - t0), "s")
