"""E05: (a) numerical check of Proposition 1 (untargeted CE = targeted CE = CW-margin
sign-PGD for a binary classifier), (b) gradient-masking sanity checks, (c) feasibility-constraint
ablation, (d) empirical robustness radius by bisection vs. the first-order estimate.
usage: python3 e05_checks_radius.py nsl|unsw"""
import sys, time, numpy as np, torch, torch.nn.functional as F
from scipy import stats
from nidslib import *
SMOKE = os.environ.get("SMOKE") == "1"

ds = sys.argv[1]
D = load(ds)
Xtr, ytr, Xte, yte = D["Xtr"], D["ytr"], D["Xte"], D["yte"]
masks = {"all": D["mask_all"], "num": D["mask_num"], "strict": D["mask_strict"]}
mask = D["mask_num"]; d = Xtr.shape[1]
base = load_model(f"{ds}_base_s42", d); rob = load_model(f"{ds}_pgdat_s42", d)
sur = load_model(f"{ds}_base_s101", d) if model_exists(f"{ds}_base_s101") else load_model(f"{ds}_base_s42", d)  # independent surrogate
sub = stratified_idx(yte, 300 if SMOKE else 5000, seed=11); Xs, ys = Xte[sub], yte[sub]
res = {"dataset": ds, "subset_size": int(len(sub))}
t0 = time.time()


def pgd_margin(model, X, y, eps, mask, steps=40, rand_init=False, restarts=1, seed=0):
    """Sign-PGD on the CW margin loss z_{1-y} - z_y (never saturates)."""
    model.eval(); X0 = torch.as_tensor(X); yt = torch.as_tensor(y); mk = torch.as_tensor(mask)
    a = 2.5 * eps / steps; g = torch.Generator().manual_seed(seed)
    best = X0.clone(); done = torch.zeros(len(X0), dtype=torch.bool)
    for r in range(restarts):
        x = X0.clone()
        if rand_init:
            x = torch.clamp(X0 + (2 * torch.rand(X0.shape, generator=g) - 1) * eps * mk, 0, 1)
        for _ in range(steps):
            x.requires_grad_(True)
            z = model(x); s = (2 * yt - 1).float()
            loss = (-(z[:, 1] - z[:, 0]) * s).mean()
            gr, = torch.autograd.grad(loss, x)
            x = x.detach() + a * mk * gr.sign()
            x = torch.max(torch.min(x, X0 + eps), X0 - eps).clamp(0, 1)
        with torch.no_grad():
            succ = model(x).argmax(1) != yt
        upd = succ & ~done if restarts > 1 else torch.ones(len(X0), dtype=torch.bool)
        best[upd] = x[upd]; done |= succ
    return best.numpy()


# (a) Proposition 1 check
chk = {}
for tag, m in (("base", base), ("robust", rob)):
    xu = pgd(m, Xs, ys, 0.1, mask)
    xt = pgd(m, Xs, ys, 0.1, mask, target=1 - ys)
    xc = pgd_margin(m, Xs, ys, 0.1, mask)
    z = logits_np(m, Xs)
    p_minor = torch.softmax(torch.as_tensor(z), 1).numpy()
    sat = int((p_minor.min(1) == 0).sum())
    chk[tag] = dict(max_abs_untargeted_vs_targeted=float(np.abs(xu - xt).max()),
                    frac_coords_diff_untargeted_vs_targeted=float((xu != xt).mean()),
                    pred_agreement_untargeted_vs_targeted=float((predict(m, xu) == predict(m, xt)).mean()),
                    max_abs_untargeted_vs_cw=float(np.abs(xu - xc).max()),
                    frac_coords_diff_untargeted_vs_cw=float((xu != xc).mean()),
                    pred_agreement_untargeted_vs_cw=float((predict(m, xu) == predict(m, xc)).mean()),
                    saturated_softmax_samples=sat,
                    max_abs_margin=float(np.abs(z[:, 1] - z[:, 0]).max()))
    print(f"[{ds}] Prop.1 check {tag}: {chk[tag]}", flush=True)
res["prop1_check"] = chk

# (b) gradient-masking sanity checks
gm = {}
for tag, m in (("base", base), ("robust", rob)):
    pc = predict(m, Xs); gm[tag] = {}
    for e in (0.1, 0.3):
        att = {
            "pgd40": pgd(m, Xs, ys, e, mask),
            "pgd200_r10": pgd(m, Xs, ys, e, mask, steps=20 if SMOKE else 200, rand_init=True, restarts=2 if SMOKE else 10, seed=5),
            "cw200_r10": pgd_margin(m, Xs, ys, e, mask, steps=20 if SMOKE else 200, rand_init=True, restarts=2 if SMOKE else 10, seed=6),
            "random_search_1000": random_search(m, Xs, ys, e, mask, queries=50 if SMOKE else 1000, seed=7),
            "transfer_from_surrogate": pgd(sur, Xs, ys, e, mask),
        }
        gm[tag][str(e)] = {k: two_sided(ys, pc, predict(m, v)) for k, v in att.items()}
        print(f"[{ds}] masking check {tag} eps={e}: " +
              " ".join(f"{k}={v['acc']:.4f}" for k, v in gm[tag][str(e)].items()) + f" ({time.time()-t0:.0f}s)", flush=True)
res["masking_check"] = gm

# (c) feasibility-constraint ablation (full test set)
ca = {}
for tag, m in (("base", base), ("robust", rob)):
    XC, yC = (Xs, ys) if SMOKE else (Xte, yte)
    pc = predict(m, XC); ca[tag] = {}
    for cs in ("all", "num", "strict"):
        ca[tag][cs] = {}
        for e in (0.05, 0.1, 0.3):
            xa = pgd(m, XC, yC, e, masks[cs], chunk=30000)
            if cs == "strict":
                xa = project_integer(xa, XC, e, D)
            ca[tag][cs][str(e)] = two_sided(yC, pc, predict(m, xa))
        print(f"[{ds}] constraints {tag} {cs:6s}: " +
              " ".join(f"eps{e}: acc={ca[tag][cs][str(e)]['acc']:.4f}/tpr={ca[tag][cs][str(e)]['tpr']:.3f}/fpr={ca[tag][cs][str(e)]['fpr']:.3f}"
                       for e in (0.05, 0.1, 0.3)), flush=True)
res["constraint_ablation"] = ca


# (d) robustness radius
def radius(m, X, y, emax=1.0, iters=3 if SMOKE else 12, steps=10 if SMOKE else 50):
    ok = predict(m, X) == y
    xa = pgd(m, X, y, emax, mask, steps=steps)
    smax = predict(m, xa) != y
    lo = np.zeros(len(X)); hi = np.full(len(X), emax); act = np.where(ok & smax)[0]
    for _ in range(iters):
        mid = (lo + hi) / 2
        xa = pgd(m, X[act], y[act], mid[act].astype(np.float32), mask, steps=steps)
        s = predict(m, xa) != y[act]
        hi[act[s]] = mid[act[s]]; lo[act[~s]] = mid[act[~s]]
    r = np.where(ok, np.where(smax, hi, np.inf), 0.0)
    return r, ok


rad = {}
arrs = {}
for tag, m in (("base", base), ("robust", rob)):
    r, ok = radius(m, Xs, ys)
    g = input_gradient(m, Xs); mg = margin_np(m, Xs)
    fo = np.abs(mg) / np.maximum((np.abs(g) * mask).sum(1), 1e-12)
    fin = ok & np.isfinite(r)
    rho = stats.spearmanr(r[fin], fo[fin])
    s = {"spearman_radius_vs_first_order": float(rho.correlation), "n_finite": int(fin.sum())}
    for c, cn in ((0, "normal"), (1, "attack")):
        sel = ok & (ys == c)
        rr = r[sel]
        s[cn] = dict(n_correct=int(sel.sum()), censored=float(np.isinf(rr).mean()),
                     median=float(np.median(rr)), q25=float(np.percentile(rr, 25)), q75=float(np.percentile(rr, 75)),
                     median_first_order=float(np.median(fo[sel])),
                     mean_abs_margin=float(np.abs(mg[sel]).mean()),
                     median_grad_l1=float(np.median((np.abs(g) * mask).sum(1)[sel])))
    rad[tag] = s
    arrs[f"{tag}_radius"] = r; arrs[f"{tag}_first_order"] = fo; arrs[f"{tag}_ok"] = ok
    print(f"[{ds}] radius {tag}: {s} ({time.time()-t0:.0f}s)", flush=True)
arrs["y"] = ys
np.savez_compressed(os.path.join(RES, f"e05_{ds}_radius_arrays{'_smoke' if SMOKE else ''}.npz"), **arrs)
res["radius"] = rad
save_json(res, f"e05_{ds}_checks{'_smoke' if SMOKE else ''}.json")
print("done", round(time.time() - t0), "s")
