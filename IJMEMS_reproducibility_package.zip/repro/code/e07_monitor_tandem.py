"""E07: explanation-space monitor vs. adversarial-input detection baselines (train->test
protocol, generalisation across budgets/attacks), and the tandem defence
(robust classifier + explanation monitor) under non-adaptive and adaptive white-box attacks.
usage: python3 e07_monitor_tandem.py nsl|unsw"""
import sys, time, numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from scipy.spatial.distance import cdist
from sklearn.metrics import roc_auc_score
from nidslib import *
SMOKE = os.environ.get("SMOKE") == "1"
NS = (lambda full, small: small if SMOKE else full)
SFX = "_smoke" if SMOKE else ""

ds = sys.argv[1]
D = load(ds)
Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
d = Xtr.shape[1]
B = Xtr[stratified_idx(ytr, 1000, seed=21)]                  # EG background (as in E06)
used = set(stratified_idx(ytr, 1000, seed=21).tolist())


def strat_excl(y, n, seed, excl):
    rng = np.random.default_rng(seed); out = []
    for c in (0, 1):
        pool = np.setdiff1d(np.where(y == c)[0], np.fromiter(excl, int, len(excl)))
        out.append(rng.choice(pool, int(round(n * (y == c).mean())), replace=False))
    return np.sort(np.concatenate(out))


itr = strat_excl(ytr, NS(3000, 200), 71, used); used |= set(itr.tolist())
iref = strat_excl(ytr, NS(2000, 300), 81, used); used |= set(iref.tolist())
ifit = strat_excl(ytr, NS(10000, 1000), 91, used)
ite = stratified_idx(yte, NS(3000, 200), seed=72)
Xm, ym = Xtr[itr], ytr[itr]                 # monitor-training pool (from the training split)
Xt, yt = Xte[ite], yte[ite]                 # monitor-test pool (from the test split)
res = {"dataset": ds, "n_monitor_train": int(len(itr)), "n_monitor_test": int(len(ite))}
t0 = time.time()
KINDS = ["raw", "grad", "gxi", "eg", "maha", "lid"]


def maha_stats(m):
    H = hidden_np(m, Xtr[ifit]); yy = ytr[ifit]; st = []
    for h in H:
        mus = [h[yy == c].mean(0) for c in (0, 1)]
        Z = np.vstack([h[yy == c] - mus[c] for c in (0, 1)])
        P = np.linalg.pinv(np.cov(Z, rowvar=False) + 1e-6 * np.eye(h.shape[1]))
        st.append((mus, P))
    return st


def maha_feat(m, X, st):
    H = hidden_np(m, X); out = []
    for h, (mus, P) in zip(H, st):
        out.append(np.min(np.stack([np.einsum("ij,jk,ik->i", h - mu, P, h - mu) for mu in mus], 1), 1))
    return np.stack(out, 1)


def lid_feat(m, X, ref, k=20):
    H = hidden_np(m, X); out = []
    for h, r in zip(H, ref):
        dd = np.sort(cdist(h, r), 1)
        dd = np.where(dd[:, :1] == 0, dd[:, 1:k + 2], dd[:, :k + 1])[:, :k]
        dd = np.maximum(dd, 1e-12)
        out.append(-1.0 / (np.mean(np.log(dd / dd[:, -1:]), 1) - 1e-12))
    return np.stack(out, 1)


def fs_score(m, X):
    p0 = torch.softmax(torch.as_tensor(logits_np(m, X)), 1).numpy(); best = np.zeros(len(X))
    for bits in (3, 4, 5):
        L = 2 ** bits - 1; Xq = X.copy()
        Xq[:, mask > 0] = np.round(Xq[:, mask > 0] * L) / L
        p1 = torch.softmax(torch.as_tensor(logits_np(m, Xq)), 1).numpy()
        best = np.maximum(best, np.abs(p0 - p1).sum(1))
    return best


def features(m, X, kind, ctx, seed):
    if kind == "raw": return X
    if kind == "grad": return input_gradient(m, X)
    if kind == "gxi": return X * input_gradient(m, X)
    if kind == "eg": return eg_attrib(m, X, B, K=200, seed=seed)
    if kind == "maha": return maha_feat(m, X, ctx["maha"])
    if kind == "lid": return lid_feat(m, X, ctx["lid"])


def surrogate(m, x, beta=10.0):
    h = x
    for mod in m.net:
        if isinstance(mod, nn.Linear): h = mod(h)
        elif isinstance(mod, nn.ReLU): h = F.softplus(h, beta=beta)
    return h


def adaptive_attack(m, clf, tau, X, y, eps, steps=NS(100, 5), K=NS(16, 4), lams=(0.5, 2.0, 8.0), mu_m=0.5, seed=0, chunk=500):
    """White-box attack on classifier AND explanation monitor (EOT over the EG sampling,
    softplus surrogate for second-order terms, Dombrowski et al. 2019)."""
    sc, lr = clf.named_steps["sc"], clf.named_steps["lr"]
    mu = torch.tensor(sc.mean_, dtype=torch.float32); sd = torch.tensor(sc.scale_, dtype=torch.float32)
    w = torch.tensor(lr.coef_[0], dtype=torch.float32); b0 = float(lr.intercept_[0])
    Bt = torch.as_tensor(B); mk = torch.as_tensor(mask); g = torch.Generator().manual_seed(seed)
    att = []
    for lam in lams:
        xs = np.empty_like(X)
        for i in range(0, len(X), chunk):
            x0 = torch.as_tensor(X[i:i + chunk]); tg = torch.as_tensor(1 - y[i:i + chunk]); n = len(x0)
            x = torch.clamp(x0 + 0.5 * (2 * torch.rand(x0.shape, generator=g) - 1) * eps * mk, 0, 1)
            a = 2.5 * eps / steps
            for _ in range(steps):
                x.requires_grad_(True)
                ce = F.cross_entropy(m(x), tg, reduction="none")
                idx = torch.randint(0, len(Bt), (n, K), generator=g); al = torch.rand(n, K, 1, generator=g)
                bb = Bt[idx]; z = (bb + al * (x[:, None, :] - bb)).reshape(-1, d)
                o = surrogate(m, z); f = o[:, 1] - o[:, 0]
                gz, = torch.autograd.grad(f.sum(), z, create_graph=True)
                phi = ((x[:, None, :] - bb) * gz.view(n, K, d)).mean(1)
                s = ((phi - mu) / sd) @ w + b0
                loss = ce + lam * F.relu(s - tau + mu_m)
                gr, = torch.autograd.grad(loss.sum(), x)
                x = x.detach() - a * mk * gr.sign()
                x = torch.max(torch.min(x, x0 + eps), x0 - eps).clamp(0, 1)
            xs[i:i + chunk] = x.numpy()
        flip = predict(m, xs) != y
        s_true = clf.decision_function(eg_attrib(m, xs, B, K=200, seed=seed + 4242))
        att.append((xs, flip, s_true))
    out = att[0][0].copy(); chosen = np.full(len(X), -1)
    for j, (xs, flip, s) in enumerate(att):               # 1) first successful attempt
        ok = flip & (s < tau) & (chosen < 0); out[ok] = xs[ok]; chosen[ok] = j
    for j, (xs, flip, s) in enumerate(att):               # 2) otherwise a flipped one with lowest score
        cand = flip & (chosen < 0)
        if j == 0:
            best_s = np.where(cand, s, np.inf); best_j = np.where(cand, 0, -1)
        else:
            upd = cand & (s < best_s); best_s = np.where(upd, s, best_s); best_j = np.where(upd, j, best_j)
    for j in range(len(att)):
        sel = (chosen < 0) & (best_j == j); out[sel] = att[j][0][sel]
    return out


def system(y, p, flag):
    alert = (p == 1) | flag
    return dict(SDR=float(alert[y == 1].mean()), miss_rate=float((~alert)[y == 1].mean()),
                intrusion_FPR=float(((p == 1) & ~flag)[y == 0].mean()),
                flag_rate_normal=float(flag[y == 0].mean()), flag_rate_attack=float(flag[y == 1].mean()),
                total_alert_rate_normal=float(alert[y == 0].mean()),
                cls_tpr=float((p[y == 1] == 1).mean()), cls_fpr=float((p[y == 0] == 1).mean()))


models = {"base": load_model(f"{ds}_base_s42", d), "robust": load_model(f"{ds}_pgdat_s42", d)}
mon = {}; tandem = {}
for tag, m in models.items():
    ctx = {"maha": maha_stats(m), "lid": hidden_np(m, Xtr[iref])}
    Xm_a = pgd(m, Xm, ym, 0.1, mask)
    cond = {f"pgd_{e}": pgd(m, Xt, yt, e, mask) for e in (0.02, 0.05, 0.1, 0.2, 0.3)}
    cond["fgsm_0.1"] = fgsm(m, Xt, yt, 0.1, mask)
    cond["rs_0.1"] = random_search(m, Xt, yt, 0.1, mask, queries=NS(1000, 50), seed=3)
    pcl = predict(m, Xt)
    succ = {k: float((predict(m, v) != yt).mean()) for k, v in cond.items()}
    mon[tag] = {"attack_error_rate_on_pool": succ, "clean_error_rate_on_pool": float((pcl != yt).mean()), "kinds": {}}
    scores = {}
    for kind in KINDS:
        F0 = features(m, Xm, kind, ctx, 11); F1 = features(m, Xm_a, kind, ctx, 12)
        clf = lr_monitor(F0, F1)
        tau = float(np.percentile(clf.decision_function(F0), 95))
        s_cl = clf.decision_function(features(m, Xt, kind, ctx, 13))
        r = {"tau": tau, "fpr_at_tau_clean_test": float((s_cl >= tau).mean()), "cond": {}}
        for cn, Xa in cond.items():
            s_ad = clf.decision_function(features(m, Xa, kind, ctx, 14))
            yy = np.r_[np.zeros(len(s_cl)), np.ones(len(s_ad))]; ss = np.r_[s_cl, s_ad]
            auc, lo, hi = auc_ci(yy, ss)
            r["cond"][cn] = dict(auc=auc, lo=lo, hi=hi, tpr_at_tau=float((s_ad >= tau).mean()))
            scores[(kind, cn)] = (yy, ss)
        mon[tag]["kinds"][kind] = r
        if kind == "eg":
            mon_clf, mon_tau = clf, tau
        print(f"[{ds}] {tag} monitor {kind:5s}: clean-test FPR@tau={r['fpr_at_tau_clean_test']:.3f} | " +
              " ".join(f"{c}:{v['auc']:.3f}" for c, v in r["cond"].items()) + f" ({time.time()-t0:.0f}s)", flush=True)
    s0 = fs_score(m, Xm); tau = float(np.percentile(s0, 95)); s_cl = fs_score(m, Xt)
    r = {"tau": tau, "fpr_at_tau_clean_test": float((s_cl >= tau).mean()), "cond": {}}
    for cn, Xa in cond.items():
        s_ad = fs_score(m, Xa); yy = np.r_[np.zeros(len(s_cl)), np.ones(len(s_ad))]
        auc, lo, hi = auc_ci(yy, np.r_[s_cl, s_ad]); r["cond"][cn] = dict(auc=auc, lo=lo, hi=hi, tpr_at_tau=float((s_ad >= tau).mean()))
    mon[tag]["kinds"]["fs"] = r
    print(f"[{ds}] {tag} monitor fs   : " + " ".join(f"{c}:{v['auc']:.3f}" for c, v in r["cond"].items()), flush=True)
    yy, s_eg = scores[("eg", "pgd_0.1")]; _, s_raw = scores[("raw", "pgd_0.1")]
    mon[tag]["delong_eg_vs_raw_pgd0.1"] = delong_test(yy, s_eg, s_raw)
    yy, s_gr = scores[("grad", "pgd_0.1")]
    mon[tag]["delong_eg_vs_grad_pgd0.1"] = delong_test(yy, s_eg, s_gr)

    # ---- tandem system evaluation
    tdm = {}
    flag_of = lambda X: mon_clf.decision_function(eg_attrib(m, X, B, K=200, seed=99)) >= mon_tau
    sets = {"clean": Xt, "pgd_0.1": cond["pgd_0.1"], "pgd_0.3": cond["pgd_0.3"]}
    for e in (0.1, 0.3):
        sets[f"adaptive_{e}"] = adaptive_attack(m, mon_clf, mon_tau, Xt, yt, e, seed=int(e * 100))
        print(f"[{ds}] {tag} adaptive eps={e} done ({time.time()-t0:.0f}s)", flush=True)
    for sn, Xs in sets.items():
        p = predict(m, Xs); fl = flag_of(Xs)
        tdm[sn] = {"classifier_only": system(yt, p, np.zeros(len(p), bool)), "with_monitor": system(yt, p, fl)}
        a, b = tdm[sn]["classifier_only"], tdm[sn]["with_monitor"]
        print(f"[{ds}] tandem {tag:6s} {sn:12s} cls-only SDR={a['SDR']:.3f} FPR={a['intrusion_FPR']:.3f} | "
              f"+monitor SDR={b['SDR']:.3f} intrusionFPR={b['intrusion_FPR']:.3f} flag(normal)={b['flag_rate_normal']:.3f}", flush=True)
    tandem[tag] = tdm
    res["monitors"] = mon; res["tandem"] = tandem
    save_json(res, f"e07_{ds}_monitor_tandem{SFX}.json")

# monitor AUC across training seeds (EG vs raw, train->test, PGD 0.1)
acr = {}
for s in NS(SEEDS, [42]):
    nm = f"{ds}_base_s{s}"
    if not model_exists(nm): continue
    m = load_model(nm, d); Xm_a = pgd(m, Xm, ym, 0.1, mask); Xt_a = pgd(m, Xt, yt, 0.1, mask)
    acr[str(s)] = {}
    for kind in ("raw", "eg"):
        f = (lambda X, sd: X) if kind == "raw" else (lambda X, sd: eg_attrib(m, X, B, K=200, seed=sd))
        clf = lr_monitor(f(Xm, 1), f(Xm_a, 2))
        yy = np.r_[np.zeros(len(Xt)), np.ones(len(Xt))]
        acr[str(s)][kind] = float(roc_auc_score(yy, clf.decision_function(np.vstack([f(Xt, 3), f(Xt_a, 4)]))))
    print(f"[{ds}] seed {s}: {acr[str(s)]}", flush=True)
res["monitor_auc_across_seeds"] = acr
save_json(res, f"e07_{ds}_monitor_tandem{SFX}.json")
print("done", round(time.time() - t0), "s")
