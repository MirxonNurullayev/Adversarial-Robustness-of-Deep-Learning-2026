"""E08: all figures for the journal version (new designs; vector PDF/SVG + 600-dpi PNG).
Palette: validated categorical order from the dataviz reference (blue, orange, aqua, ...).
usage: python3 e08_figures.py [fig numbers...]"""
import os, sys, json, numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from nidslib import RES, SEEDS, EPS_GRID, ppv

FIG = os.path.join(os.path.dirname(RES), "figures"); os.makedirs(FIG, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                                                         "#e87ba4", "#008300", "#6250d6", "#e34948")
INK, INK2, GRID, NEUTRAL, LIGHT = "#0b0b0b", "#52514e", "#e4e3df", "#8a8984", "#d9d8d3"
C_UND, C_DEF = ORANGE, BLUE
mpl.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "axes.linewidth": 0.6, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "lines.linewidth": 1.4, "lines.markersize": 3.5, "savefig.dpi": 600, "figure.dpi": 150,
    "pdf.fonttype": 42, "svg.fonttype": "path", "axes.titleweight": "bold", "axes.titlelocation": "left"})
DSN = {"nsl": "NSL-KDD", "unsw": "UNSW-NB15"}


def save(fig, name):
    for ext in ("png", "pdf", "svg"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"), bbox_inches="tight", pad_inches=0.03)
    plt.close(fig); print("saved", name)


def J(name):
    p = os.path.join(RES, name)
    return json.load(open(p)) if os.path.exists(p) else None


def panel(ax, letter):
    ax.set_title(f"({letter}) " + ax.get_title(loc="left"), loc="left")


# ---------------------------------------------------------------- Fig 1: architecture
def fig1():
    fig, ax = plt.subplots(figsize=(6.6, 3.3)); ax.set_xlim(0, 100); ax.set_ylim(0, 52); ax.axis("off")
    def box(x, y, w, h, title, sub, fc="#f4f3ef", ec=INK2):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.0", fc=fc, ec=ec, lw=0.8))
        ax.text(x + w / 2, y + h - 3.2, title, ha="center", va="center", fontsize=6.9, fontweight="bold")
        ax.text(x + w / 2, y + (h - 5.0) / 2, sub, ha="center", va="center", fontsize=5.9, color=INK2, linespacing=1.25)
    def arr(x1, y1, x2, y2, c=INK2, ls="-"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=7, lw=0.8, color=c, linestyle=ls))
    box(0.5, 33, 15, 15, "Network flow", "raw record r\n(numeric +\ncategorical)")
    box(19, 33, 18, 15, "Preprocessing", "log1p / min-max,\none-hot, clip to [0,1]\n(Algorithm 1)")
    box(40, 33, 21, 15, "Robust NIDS  $f_R$", "Layer 1 (PGD-AT)\nlogit margin $m(x)$\n(Algorithm 3)", fc="#e3eefb", ec=BLUE)
    box(40, 10, 21, 15, "Explanation monitor", "Layer 2: EG-SHAP $\\phi(x)$\nthen $g(\\phi(x))$\n(Algorithms 4-5)", fc="#e3eefb", ec=BLUE)
    box(65, 21.5, 34, 16, "Decision fusion", "intrusion alert if $f_R(x)=1$ and $g<\\tau$\nmanipulation alert if $g(\\phi(x))\\geq\\tau$\nno alert otherwise")
    arr(15.5, 40.5, 19, 40.5); arr(37, 40.5, 40, 40.5)
    arr(50, 33, 50, 25); ax.text(51, 29, "gradients of $m$", fontsize=5.7, color=INK2)
    arr(61, 40.5, 65, 33); arr(61, 17.5, 65, 26)
    ax.add_patch(FancyBboxPatch((0.5, 1.5), 37, 24, boxstyle="round,pad=0.3,rounding_size=1.0", fc="white", ec=RED, lw=0.8, ls="--"))
    ax.text(2, 22.3, "White-box adversary (Section 3)", fontsize=6.6, fontweight="bold", color=RED)
    ax.text(2, 17.2, "feasible set $\\mathcal{S}_\\varepsilon(x)$: masked $L_\\infty$ ball,\nbox $[0,1]$, integer grid", fontsize=5.8, color=INK2, va="center")
    ax.text(2, 11.2, "evasion: attack flow driven to $f=0$", fontsize=5.8)
    ax.text(2, 7.4, "flooding: benign flow driven to $f=1$", fontsize=5.8)
    ax.text(2, 3.6, "adaptive: also keeps $g(\\phi)<\\tau$ (Algorithm 6)", fontsize=5.8)
    arr(28, 25.6, 28, 33, c=RED, ls="--")
    save(fig, "fig01_architecture")


# ---------------------------------------------------------------- Fig 2: transition decomposition
def fig2():
    rows = []
    for ds in ("nsl", "unsw"):
        r = J(f"e03_{ds}_multiseed.json")
        if r is None or "42" not in r["runs"]: continue
        for kind, lab in (("base", "Undefended"), ("pgdat", "PGD-AT")):
            R = r["runs"]["42"][kind]; c = R["clean"]; a = R["pgd"]["0.1"]
            P, N = c["TP"] + c["FN"], c["TN"] + c["FP"]
            ev = R["pgd"]["0.1"]["ESR"] * c["TP"]; fl = R["pgd"]["0.1"]["FSR"] * c["TN"]
            rows.append((f"{DSN[ds]}  {lab}", "attack", (c["TP"] - ev) / P, ev / P, c["FN"] / P))
            rows.append((f"{DSN[ds]}  {lab}", "normal", (c["TN"] - fl) / N, fl / N, c["FP"] / N))
    if not rows: return
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.45), sharey=True)
    for ax, cls, title, flipc, flipl in ((axs[0], "attack", "Attack records: evasion", ORANGE, "detected → missed (evasion)"),
                                         (axs[1], "normal", "Normal records: false-alarm flooding", RED, "correct → false alarm (flooding)")):
        sel = [r for r in rows if r[1] == cls]
        y = np.arange(len(sel))[::-1]
        a = np.array([s[2] for s in sel]); b = np.array([s[3] for s in sel]); c = np.array([s[4] for s in sel])
        ax.barh(y, a, color=LIGHT, height=0.62, label="correct, unchanged", edgecolor="white", linewidth=1)
        ax.barh(y, b, left=a, color=flipc, height=0.62, label=flipl, edgecolor="white", linewidth=1)
        ax.barh(y, c, left=a + b, color="#b9b8b1", height=0.62, label="already wrong on clean input", hatch="////",
                edgecolor="white", linewidth=0)
        for yi, ai, bi in zip(y, a, b):
            if bi > 0.04:
                ax.text(ai + bi / 2, yi, f"{bi*100:.1f}%", ha="center", va="center", fontsize=6.8, color="white", fontweight="bold")
        ax.set_yticks(y); ax.set_yticklabels([s[0] for s in sel]); ax.set_xlim(0, 1)
        ax.set_xticks([0, .25, .5, .75, 1]); ax.set_xticklabels(["0", "25%", "50%", "75%", "100%"])
        ax.set_title(title); ax.grid(axis="y", visible=False)
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=1, fontsize=6.6, handlelength=1.2)
    fig.tight_layout(w_pad=1.2)
    save(fig, "fig02_two_sided_transitions")


# ---------------------------------------------------------------- Fig 3: TPR / FPR vs eps
def seed_curve(r, kind, metric, attack="pgd"):
    E = [0.0] + EPS_GRID; vals = []
    for s in r["runs"]:
        R = r["runs"][s][kind]
        vals.append([R["clean"][metric]] + [R[attack][str(e)][metric] for e in EPS_GRID])
    v = np.array(vals); return np.array(E), v.mean(0), v.std(0, ddof=1) if len(v) > 1 else np.zeros(v.shape[1]), len(v)


def fig3():
    dss = [ds for ds in ("nsl", "unsw") if J(f"e03_{ds}_multiseed.json")]
    if not dss: return
    fig, axs = plt.subplots(len(dss), 2, figsize=(6.6, 2.3 * len(dss)), squeeze=False)
    L = "abcd"
    for i, ds in enumerate(dss):
        r = J(f"e03_{ds}_multiseed.json")
        for j, (met, lab) in enumerate((("tpr", "Detection rate TPR (attack recall)"), ("fpr", "False-alarm rate FPR"))):
            ax = axs[i, j]
            for kind, col, name in (("base", C_UND, "Undefended"), ("pgdat", C_DEF, "PGD-AT")):
                E, mu, sd, n = seed_curve(r, kind, met)
                ax.plot(E, mu, "-o", color=col, label=f"{name} (mean ± SD, n={n})")
                ax.fill_between(E, mu - sd, mu + sd, color=col, alpha=0.18, linewidth=0)
            ax.set_ylim(-0.02, 1.02); ax.set_xlabel(r"PGD budget $\varepsilon$ ($L_\infty$, masked)")
            ax.set_ylabel(lab); ax.set_title(f"{DSN[ds]}: {'evasion' if met=='tpr' else 'flooding'}")
            panel(ax, L[2 * i + j])
            if i == 0 and j == 0: ax.legend(loc="lower left")
    fig.tight_layout(h_pad=1.2, w_pad=1.5)
    save(fig, "fig03_tpr_fpr_vs_eps")


# ---------------------------------------------------------------- Fig 4: ROC-space trajectories
def fig4():
    dss = [ds for ds in ("nsl", "unsw") if J(f"e03_{ds}_multiseed.json")]
    if not dss: return
    fig, axs = plt.subplots(1, len(dss), figsize=(3.3 * len(dss), 3.0), squeeze=False)
    for i, ds in enumerate(dss):
        ax = axs[0, i]; r = J(f"e03_{ds}_multiseed.json")
        ax.fill_between([0, 1], [0, 1], [0, 0], color="#fbe3dc", alpha=0.6, linewidth=0)
        ax.plot([0, 1], [0, 1], color=NEUTRAL, lw=0.8, ls="--")
        ax.text(0.62, 0.18, "J < 0, PLR < 1\n(alarm lowers the\nodds of intrusion)", fontsize=6.4, color=INK2, ha="center")
        for kind, col, name in (("base", C_UND, "Undefended"), ("pgdat", C_DEF, "PGD-AT")):
            E, t, _, _ = seed_curve(r, kind, "tpr"); _, f, _, _ = seed_curve(r, kind, "fpr")
            ax.plot(f, t, "-", color=col, lw=1.2, label=name)
            ax.scatter(f, t, s=[10 + 60 * e for e in E], color=col, edgecolor="white", linewidth=0.6, zorder=3)
            ax.annotate("clean", (f[0], t[0]), xytext=(4, 4), textcoords="offset points", fontsize=6.3, color=col)
            ax.annotate(r"$\varepsilon$=0.3", (f[-1], t[-1]), xytext=(-24, -9), textcoords="offset points", fontsize=6.3, color=col)
        ax.set_xlim(0, 1.01); ax.set_ylim(0, 1.01); ax.set_aspect("equal")
        ax.set_xlabel("False-alarm rate (FPR)"); ax.set_ylabel("Detection rate (TPR)")
        ax.set_title(f"{DSN[ds]}: operating point under PGD"); panel(ax, "ab"[i])
        if i == 0: ax.legend(loc="upper left", fontsize=7)
    fig.tight_layout(w_pad=2)
    save(fig, "fig04_roc_trajectories")


# ---------------------------------------------------------------- Fig 5: operational impact
def fig5():
    r = J("e03_nsl_multiseed.json")
    if r is None: return
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.7))
    pi = np.logspace(-5, -0.3, 300)
    ax = axs[0]
    for kind, col, name in (("base", C_UND, "Undefended"), ("pgdat", C_DEF, "PGD-AT")):
        E, t, _, _ = seed_curve(r, kind, "tpr"); _, f, _, _ = seed_curve(r, kind, "fpr")
        i1 = E.tolist().index(0.1)
        ax.plot(pi, ppv(t[0], f[0], pi), color=col, ls="-", label=f"{name}, clean")
        ax.plot(pi, ppv(t[i1], f[i1], pi), color=col, ls="--", label=f"{name}, PGD $\\varepsilon$=0.1")
    ax.plot(pi, pi, color=NEUTRAL, lw=0.8, ls=":", label="PPV = base rate (uninformative)")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_ylim(1e-6, 1.2)
    ax.set_xlabel(r"Base rate of intrusions $\pi$"); ax.set_ylabel("Precision of an alarm, PPV($\\pi$)")
    ax.set_title("NSL-KDD: Bayesian detection rate"); ax.legend(loc="lower right", fontsize=6.3); panel(ax, "a")
    ax = axs[1]
    for ds, ls in (("nsl", "-"), ("unsw", "--")):
        rr = J(f"e03_{ds}_multiseed.json")
        if rr is None: continue
        for kind, col, name in (("base", C_UND, "Undefended"), ("pgdat", C_DEF, "PGD-AT")):
            E, t, _, _ = seed_curve(rr, kind, "tpr"); _, f, _, _ = seed_curve(rr, kind, "fpr"); i1 = E.tolist().index(0.1)
            dF = max(f[i1] - f[0], 1e-9); dN = max(t[0] - t[i1], 1e-9)
            ax.plot(pi, (1 - pi) * dF / (pi * dN), color=col, ls=ls, label=f"{name}, {DSN[ds]}")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_ylim(1, 1e7)
    ax.text(1.3e-5, 1.6, "below a curve: flooding term dominates", fontsize=6.2, color=INK2)
    ax.set_xlabel(r"Base rate of intrusions $\pi$"); ax.set_ylabel(r"Critical cost ratio $\kappa_c=c_{FN}/c_{FP}$")
    ax.set_title(r"Cost dominance at $\varepsilon$=0.1"); ax.legend(loc="upper right", fontsize=6.3); panel(ax, "b")
    fig.tight_layout(w_pad=2)
    save(fig, "fig05_operational_impact")


# ---------------------------------------------------------------- Fig 6: robustness radius
def fig6():
    dss = [ds for ds in ("nsl", "unsw") if os.path.exists(os.path.join(RES, f"e05_{ds}_radius_arrays.npz"))]
    if not dss: return
    fig, axs = plt.subplots(1, len(dss) + 1, figsize=(6.6, 2.4))
    for i, ds in enumerate(dss):
        A = np.load(os.path.join(RES, f"e05_{ds}_radius_arrays.npz")); y = A["y"]; ax = axs[i]
        grid = np.linspace(0, 1, 401)
        for tag, col, name in (("base", C_UND, "Undefended"), ("robust", C_DEF, "PGD-AT")):
            r = A[f"{tag}_radius"]; ok = A[f"{tag}_ok"]
            for c, ls, cn in ((0, "-", "normal"), (1, "--", "attack")):
                rr = r[ok & (y == c)]
                ax.plot(grid, [(rr <= g).mean() for g in grid], color=col, ls=ls, lw=1.2, label=f"{name}, {cn}")
        ax.set_xlabel(r"budget $\varepsilon$"); ax.set_ylabel(r"$P(\varepsilon^{*}\leq\varepsilon)$ (flip rate)")
        ax.set_title(f"{DSN[ds]}: radius CDF"); ax.set_ylim(0, 1.02); panel(ax, "abc"[i])
        if i == 0: ax.legend(fontsize=6.2, loc="lower right")
    A = np.load(os.path.join(RES, f"e05_{dss[0]}_radius_arrays.npz")); ax = axs[-1]
    for tag, col, name in (("base", C_UND, "Undefended"), ("robust", C_DEF, "PGD-AT")):
        r = A[f"{tag}_radius"]; fo = A[f"{tag}_first_order"]; ok = A[f"{tag}_ok"] & np.isfinite(r) & (r > 0)
        ax.scatter(fo[ok], r[ok], s=3, alpha=0.35, color=col, linewidth=0, label=name)
    ax.plot([1e-4, 2], [1e-4, 2], color=NEUTRAL, lw=0.8, ls="--")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-4, 2); ax.set_ylim(1e-4, 2)
    ax.set_xlabel(r"first-order $|m(x)|/\|M\odot\nabla m(x)\|_1$"); ax.set_ylabel(r"bisection $\varepsilon^{*}(x)$")
    ax.set_title(f"{DSN[dss[0]]}: Prop. 4 check"); ax.legend(fontsize=6.2, markerscale=3, loc="upper left"); panel(ax, "abc"[len(dss)])
    fig.tight_layout(w_pad=1.3)
    save(fig, "fig06_robustness_radius")


# ---------------------------------------------------------------- Fig 7: defence frontier
def fig7():
    dss = [ds for ds in ("nsl", "unsw") if J(f"e04_{ds}_defenses.json")]
    if not dss: return
    fig, axs = plt.subplots(1, len(dss), figsize=(3.3 * len(dss), 2.9), squeeze=False)
    sty = {"pgdat": (C_DEF, "s", "PGD-AT (label: $\\varepsilon_{train}$)"), "trades": (AQUA, "^", "TRADES (label: $\\beta$)"),
           "mart": (VIOLET, "D", "MART ($\\beta$=6)"), "base": (C_UND, "o", "Undefended")}
    for i, ds in enumerate(dss):
        r = J(f"e04_{ds}_defenses.json")["models"]; ax = axs[0, i]
        for meth in ("base", "pgdat", "trades", "mart"):
            items = sorted([v for v in r.values() if v["method"] == meth], key=lambda v: (v["eps_train"] or 0, v["beta"] or 0))
            if not items: continue
            col, mk, lab = sty[meth]
            xs = [v["clean"]["acc"] for v in items]; ys = [v["pgd"]["0.3"]["acc"] for v in items]
            ax.plot(xs, ys, "-" if len(items) > 1 else "none", color=col, marker=mk, ms=4.5, lw=1.0, label=lab)
            for j, (v, x, y) in enumerate(zip(items, xs, ys)):
                tag = f"{v['eps_train']}" if meth == "pgdat" else (f"{v['beta']:g}" if meth == "trades" else "")
                if tag:
                    ax.annotate(tag, (x, y), xytext=(4, -9 if j % 2 else 4), textcoords="offset points", fontsize=5.8, color=col)
        ax.set_xlabel("Clean accuracy"); ax.set_ylabel(r"Accuracy under PGD-40, $\varepsilon$=0.3")
        ax.set_title(f"{DSN[ds]}"); panel(ax, "ab"[i])
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=4, fontsize=6.4, bbox_to_anchor=(0.5, 1.02), handlelength=1.4)
    fig.tight_layout(rect=(0, 0, 1, 0.9), w_pad=2)
    save(fig, "fig07_defence_frontier")


# ---------------------------------------------------------------- Fig 8: explanations
def fig8():
    r = J("e06_nsl_explain.json")
    if r is None: return
    A = np.load(os.path.join(RES, "e06_nsl_arrays.npz"))
    fig, axs = plt.subplots(1, 3, figsize=(6.8, 2.7), gridspec_kw={"width_ratios": [1.25, 1.25, 1]})
    names = json.load(open(os.path.join(os.path.dirname(RES), "artifacts", "nsl_meta.json")))["feature_names"]
    gc, ga = A["base_gc"], A["base_ga"]; order = np.argsort(-gc)[:10]
    y = np.arange(len(order))[::-1]
    ax = axs[0]
    ax.barh(y + 0.2, gc[order], height=0.38, color=NEUTRAL, label="clean")
    ax.barh(y - 0.2, ga[order], height=0.38, color=C_UND, label="PGD ε=0.1")
    ax.set_yticks(y); ax.set_yticklabels([names[j] for j in order], fontsize=6.4)
    ax.set_xlabel(r"mean $|\phi_i|$ (logit-margin units)"); ax.set_title("Importance shift"); ax.legend(fontsize=6.4, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2)
    ax.grid(axis="y", visible=False); panel(ax, "a")
    ax = axs[1]
    dn = A["base_signed_adv_normal"] - A["base_signed_clean_normal"]; da = A["base_signed_adv_attack"] - A["base_signed_clean_attack"]
    ax.barh(y + 0.2, dn[order], height=0.38, color=RED, label="normal records (→ attack)")
    ax.barh(y - 0.2, da[order], height=0.38, color=C_DEF, label="attack records (→ normal)")
    ax.axvline(0, color=INK2, lw=0.6)
    ax.set_yticks(y); ax.set_yticklabels([]); ax.set_xlabel(r"mean change of signed $\phi_i$")
    ax.set_title("Directional shift"); ax.legend(fontsize=6.0, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=1)
    ax.grid(axis="y", visible=False); panel(ax, "b")
    ax = axs[2]
    K = np.array([p["K"] for p in r["convergence"]["points"]]); e = np.array([p["rmse"] for p in r["convergence"]["points"]])
    ax.loglog(K, e, "-o", color=C_DEF, label=f"EG estimator (slope {r['convergence']['loglog_slope']:.2f})")
    ax.loglog(K, e[0] * (K / K[0]) ** -0.5, color=NEUTRAL, ls="--", lw=0.8, label=r"$\propto K^{-1/2}$")
    ax.set_xlabel("Monte-Carlo samples K"); ax.set_ylabel("completeness residual (RMSE)")
    ax.set_title("EG convergence"); ax.legend(fontsize=6.2, loc="lower left"); panel(ax, "c")
    fig.tight_layout(w_pad=0.8)
    save(fig, "fig08_explanations")


# ---------------------------------------------------------------- Fig 9: monitors
MON = [("eg", "EG-SHAP (ours)"), ("raw", "Raw features"), ("gxi", "Gradient×input"), ("grad", "Saliency"),
       ("maha", "Mahalanobis"), ("lid", "LID"), ("fs", "Feature squeezing"), ("manda", "MANDA-style")]


def mon_kinds(ds, tag="base"):
    """Monitor results of E07, with the MANDA-style baseline of E10 merged in when available."""
    mm = dict(J(f"e07_{ds}_monitor_tandem.json")["monitors"][tag]["kinds"])
    e10 = J(f"e10_{ds}_manda.json")
    if e10 and tag in e10.get("models", {}):
        mm["manda"] = e10["models"][tag]
    return mm


def fig9():
    dss = [ds for ds in ("nsl", "unsw") if J(f"e07_{ds}_monitor_tandem.json")]
    if not dss: return
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.7))
    ax = axs[0]; yb = np.arange(len(MON))[::-1]
    for k, (ds, off, mk) in enumerate([(d_, o, m) for d_, o, m in (("nsl", 0.14, "o"), ("unsw", -0.14, "s")) if d_ in dss]):
        mm = mon_kinds(ds)
        for yi, (kind, lab) in zip(yb, MON):
            if kind not in mm: continue
            c = mm[kind]["cond"]["pgd_0.1"]; col = C_DEF if kind == "eg" else NEUTRAL
            ax.errorbar(c["auc"], yi + off, xerr=[[c["auc"] - c["lo"]], [c["hi"] - c["auc"]]], fmt=mk, color=col,
                        ms=3.6, elinewidth=0.9, capsize=1.5, label=DSN[ds] if yi == yb[0] else None)
    ax.set_yticks(yb); ax.set_yticklabels([l for _, l in MON]); ax.set_xlabel("AUC (95% DeLong CI), PGD ε=0.1")
    from matplotlib.lines import Line2D
    hh = [Line2D([0], [0], marker=mk_, color=NEUTRAL, ls="none", ms=3.6, label=DSN[d_]) for d_, mk_ in (("nsl", "o"), ("unsw", "s")) if d_ in dss]
    ax.set_title("Detection, train→test"); ax.legend(handles=hh, fontsize=6.4, loc="upper left"); ax.grid(axis="y", visible=False)
    panel(ax, "a")
    ax = axs[1]; mm = mon_kinds(dss[0])
    E = [0.02, 0.05, 0.1, 0.2, 0.3]
    cols = {"eg": C_DEF, "raw": C_UND, "gxi": AQUA, "maha": VIOLET, "lid": MAGENTA, "fs": YELLOW, "grad": GREEN, "manda": RED}
    for kind, lab in MON:
        if kind not in mm: continue
        ax.plot(E, [mm[kind]["cond"][f"pgd_{e}"]["auc"] for e in E], "--s" if kind == "manda" else "-o", color=cols[kind],
                lw=1.6 if kind == "eg" else 1.0,
                ms=3, label=lab)
    ax.axvline(0.1, color=NEUTRAL, lw=0.7, ls=":"); ax.text(0.104, 0.415, "training\nbudget", fontsize=5.8, color=INK2)
    ax.set_xlabel(r"test budget $\varepsilon$ (monitor trained at 0.1)"); ax.set_ylabel("AUC")
    ax.set_title(f"{DSN[dss[0]]}: other budgets"); ax.set_ylim(0.4, 1.01)
    ax.legend(fontsize=5.8, loc="upper center", bbox_to_anchor=(0.45, -0.2), ncol=4, handlelength=1.2, columnspacing=0.8); panel(ax, "b")
    fig.tight_layout(w_pad=1.5)
    save(fig, "fig09_monitors")


# ---------------------------------------------------------------- Fig 10: tandem system
def fig10():
    dss = [ds for ds in ("nsl", "unsw") if J(f"e07_{ds}_monitor_tandem.json") and "tandem" in J(f"e07_{ds}_monitor_tandem.json")]
    if not dss: return
    conds = [("clean", "clean"), ("pgd_0.1", "PGD\n0.1"), ("pgd_0.3", "PGD\n0.3"), ("adaptive_0.1", "adapt.\n0.1"),
             ("adaptive_0.3", "adapt.\n0.3")]
    cfg = [("base", "classifier_only", "C0: undefended", "#f6c3ae"), ("base", "with_monitor", "C1: undefended + monitor", ORANGE),
           ("robust", "classifier_only", "C2: PGD-AT", "#a9c9ef"), ("robust", "with_monitor", "C3: tandem (PGD-AT + monitor)", BLUE)]
    fig, axs = plt.subplots(len(dss), 2, figsize=(6.6, 2.2 * len(dss) + 0.45), squeeze=False)
    for i, ds in enumerate(dss):
        T = J(f"e07_{ds}_monitor_tandem.json")["tandem"]
        for j, (met, lab) in enumerate((("SDR", "System detection rate"), ("intrusion_FPR", "False intrusion-alert rate"))):
            ax = axs[i, j]; x = np.arange(len(conds)); w = 0.2
            for k, (tag, mode, name, col) in enumerate(cfg):
                if tag not in T: continue
                v = [T[tag][c][mode][met] for c, _ in conds]
                ax.bar(x + (k - 1.5) * w, v, width=w * 0.9, color=col, label=name, edgecolor="white", linewidth=0.4)
            ax.set_xticks(x); ax.set_xticklabels([l for _, l in conds], fontsize=6.4); ax.set_ylim(0, 1.05)
            ax.set_ylabel(lab, fontsize=7.2); ax.set_title(f"{DSN[ds]}: {lab.lower()}"); ax.grid(axis="x", visible=False)
            panel(ax, "abcd"[2 * i + j])
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=4, fontsize=6.3, bbox_to_anchor=(0.5, 1.0), handlelength=1.2, columnspacing=1.0)
    fig.tight_layout(rect=(0, 0, 1, 1 - 0.32 / (2.2 * len(dss) + 0.45)), h_pad=1.2, w_pad=1.5)
    save(fig, "fig10_tandem")


ALL = {1: fig1, 2: fig2, 3: fig3, 4: fig4, 5: fig5, 6: fig6, 7: fig7, 8: fig8, 9: fig9, 10: fig10}
if __name__ == "__main__":
    which = [int(a) for a in sys.argv[1:]] or list(ALL)
    for k in which:
        ALL[k]()
