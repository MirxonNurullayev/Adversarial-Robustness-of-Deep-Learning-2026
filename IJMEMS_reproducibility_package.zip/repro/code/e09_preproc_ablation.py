"""E09: preprocessing ablation (seed 42): numeric transform h = identity vs log1p,
for the undefended and PGD-AT detectors.  usage: python3 e09_preproc_ablation.py"""
import time, numpy as np
from sklearn.metrics import roc_auc_score
from nidslib import *

res = {}
t0 = time.time()
for name in ("nsl_log", "unsw_lin"):
    D = load(name); Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
    d = Xtr.shape[1]; res[name] = {}
    for kind in ("base", "pgdat"):
        nm = f"{name}_{kind}_s42"
        if model_exists(nm):
            m = load_model(nm, d)
        else:
            m = train_standard(Xtr, ytr, 42, tag=nm) if kind == "base" else train_robust(Xtr, ytr, mask, 42, "pgdat", eps=0.1, tag=nm)
            save_model(m, nm)
        pc = predict(m, Xte)
        r = {"clean": rates(yte, pc), "clean_auc": float(roc_auc_score(yte, margin_np(m, Xte))), "pgd": {}}
        for e in (0.1, 0.3):
            r["pgd"][str(e)] = two_sided(yte, pc, predict(m, pgd(m, Xte, yte, e, mask, chunk=30000)))
        res[name][kind] = r
        print(f"[{name} {kind}] clean acc={r['clean']['acc']:.4f} fpr={r['clean']['fpr']:.4f} | PGD0.1 acc={r['pgd']['0.1']['acc']:.4f} "
              f"tpr={r['pgd']['0.1']['tpr']:.4f} fpr={r['pgd']['0.1']['fpr']:.4f} | PGD0.3 acc={r['pgd']['0.3']['acc']:.4f} ({time.time()-t0:.0f}s)", flush=True)
        save_json(res, "e09_preproc_ablation.json")
print("done", round(time.time() - t0), "s")
