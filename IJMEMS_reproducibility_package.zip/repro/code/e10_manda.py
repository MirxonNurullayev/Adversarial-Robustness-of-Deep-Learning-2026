"""E10: MANDA-style detector of adversarial inputs (N. Wang et al., IEEE TDSC 2023) under exactly the
train->test protocol, records and attack sets of E07, as an additional NIDS-specific baseline.

MANDA combines (i) manifold evaluation: inconsistency between the target detector and a model of the
data manifold, and (ii) decision-boundary analysis: instability of the decision under small random
noise.  Re-implementation used here (no code was released with the paper):
  ME : probability that a k-NN classifier (k = 20, 10,000 training records, Euclidean distance in the
       encoded feature space) assigns the label predicted by the detector;
  DBA: for sigma in {0.01, 0.05}: mean and SD of the detector's probability of its own clean
       prediction and the flip rate over 32 Gaussian perturbations of the mutable features.
The seven scores are combined by the same standardised logistic regression and calibrated at the same
95th percentile of the training-partition clean scores as every other monitor in E07.
usage: python3 e10_manda.py nsl|unsw"""
import sys, time, numpy as np, torch
from scipy.spatial.distance import cdist
from nidslib import *

ds = sys.argv[1]
D = load(ds)
Xtr, ytr, Xte, yte, mask = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["mask_num"]
d = Xtr.shape[1]
used = set(stratified_idx(ytr, 1000, seed=21).tolist())


def strat_excl(y, n, seed, excl):                       # identical to E07
    rng = np.random.default_rng(seed); out = []
    for c in (0, 1):
        pool = np.setdiff1d(np.where(y == c)[0], np.fromiter(excl, int, len(excl)))
        out.append(rng.choice(pool, int(round(n * (y == c).mean())), replace=False))
    return np.sort(np.concatenate(out))


itr = strat_excl(ytr, 3000, 71, used); used |= set(itr.tolist())
iref = strat_excl(ytr, 2000, 81, used); used |= set(iref.tolist())
ifit = strat_excl(ytr, 10000, 91, used)
ite = stratified_idx(yte, 3000, seed=72)
Xm, ym = Xtr[itr], ytr[itr]; Xt, yt = Xte[ite], yte[ite]
Xk, yk = Xtr[ifit], ytr[ifit]                           # k-NN "manifold" reference set
K_NN, N_NOISE, SIGMAS = 20, 32, (0.01, 0.05)


def knn_agree(X, pred, chunk=1000):
    out = np.empty(len(X))
    for i in range(0, len(X), chunk):
        dd = cdist(X[i:i + chunk], Xk)
        nb = np.argpartition(dd, K_NN, axis=1)[:, :K_NN]
        out[i:i + chunk] = (yk[nb] == pred[i:i + chunk, None]).mean(1)
    return out


def dba(m, X, pred, seed):
    rng = np.random.default_rng(seed); feats = []
    p_idx = pred.astype(int)
    for s in SIGMAS:
        P = np.empty((N_NOISE, len(X))); Fl = np.empty((N_NOISE, len(X)))
        for j in range(N_NOISE):
            Xn = np.clip(X + rng.normal(0.0, s, X.shape).astype(np.float32) * mask, 0, 1).astype(np.float32)
            pr = torch.softmax(torch.as_tensor(logits_np(m, Xn)), 1).numpy()
            P[j] = pr[np.arange(len(X)), p_idx]; Fl[j] = (pr.argmax(1) != p_idx)
        feats += [P.mean(0), P.std(0), Fl.mean(0)]
    return np.stack(feats, 1)


def manda_feat(m, X, seed):
    pred = predict(m, X)
    return np.column_stack([knn_agree(X, pred), dba(m, X, pred, seed)])


res = {"dataset": ds, "method": "MANDA-style (ME: k-NN agreement, k=20, 10,000 refs; DBA: sigma 0.01/0.05, 32 draws)",
       "n_monitor_train": int(len(itr)), "n_monitor_test": int(len(ite)), "models": {}}
t0 = time.time()
for tag, nm in (("base", f"{ds}_base_s42"), ("robust", f"{ds}_pgdat_s42")):
    m = load_model(nm, d)
    Xm_a = pgd(m, Xm, ym, 0.1, mask)                                 # same attack sets as E07
    cond = {f"pgd_{e}": pgd(m, Xt, yt, e, mask) for e in (0.02, 0.05, 0.1, 0.2, 0.3)}
    cond["fgsm_0.1"] = fgsm(m, Xt, yt, 0.1, mask)
    cond["rs_0.1"] = random_search(m, Xt, yt, 0.1, mask, queries=1000, seed=3)
    F0 = manda_feat(m, Xm, 11); F1 = manda_feat(m, Xm_a, 12)
    clf = lr_monitor(F0, F1)
    tau = float(np.percentile(clf.decision_function(F0), 95))
    s_cl = clf.decision_function(manda_feat(m, Xt, 13))
    r = {"tau": tau, "fpr_at_tau_clean_test": float((s_cl >= tau).mean()), "cond": {}}
    for cn, Xa in cond.items():
        s_ad = clf.decision_function(manda_feat(m, Xa, 14))
        yy = np.r_[np.zeros(len(s_cl)), np.ones(len(s_ad))]
        auc, lo, hi = auc_ci(yy, np.r_[s_cl, s_ad])
        r["cond"][cn] = dict(auc=auc, lo=lo, hi=hi, tpr_at_tau=float((s_ad >= tau).mean()))
    res["models"][tag] = r
    print(f"[{ds}] {tag} monitor manda: clean-test FPR@tau={r['fpr_at_tau_clean_test']:.3f} | " +
          " ".join(f"{c}:{v['auc']:.3f}" for c, v in r["cond"].items()) + f" ({time.time()-t0:.0f}s)", flush=True)
    save_json(res, f"e10_{ds}_manda.json")
print("done", round(time.time() - t0), "s")
