"""E02: reproduce the conference seed-42 models and audit the raw-detector AUC
reported as 0.997 (text) vs 0.999 (Fig. 6 legend)."""
import numpy as np, torch, shap, time
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from nidslib import *

SEED = 42
D = load("nsl")
Xtr, ytr, Xte, yte, Xu = D["Xtr"], D["ytr"], D["Xte"], D["yte"], D["Xte_unclipped"]
mask = D["mask_num"]; d = Xtr.shape[1]
out = {}

# ---------------- models (bit-identical training path to the conference scripts)
t0 = time.time()
if model_exists("nsl_base_s42"):
    base = load_model("nsl_base_s42", d)
else:
    base = train_standard(Xtr, ytr, SEED, tag="base"); save_model(base, "nsl_base_s42")
print("baseline ready", round(time.time() - t0, 1), "s", flush=True)
if model_exists("nsl_pgdat_s42"):
    rob = load_model("nsl_pgdat_s42", d)
else:
    rob = train_robust(Xtr, ytr, mask, SEED, "pgdat", eps=0.1); save_model(rob, "nsl_pgdat_s42")
print("robust ready", round(time.time() - t0, 1), "s", flush=True)

for nm, X in (("unclipped", Xu), ("clipped", Xte)):
    for tag, m in (("base", base), ("robust", rob)):
        pc = predict(m, X)
        xa = pgd(m, X, yte, 0.1, mask)
        pa = predict(m, xa)
        out[f"{tag}_{nm}_clean"] = rates(yte, pc)
        out[f"{tag}_{nm}_pgd0.1"] = two_sided(yte, pc, pa)
        r = out[f"{tag}_{nm}_pgd0.1"]
        print(f"{tag:6s} {nm:9s} clean acc={out[f'{tag}_{nm}_clean']['acc']:.4f} conf="
              f"{confusion(yte, pc)} | PGD0.1 acc={r['acc']:.4f} TP={r['TP']} FN={r['FN']} TN={r['TN']} FP={r['FP']}", flush=True)

# ---------------- conference detector protocol (exp4 vs exp5 sampling)
def conf_subset(path):
    rng = np.random.default_rng(SEED)
    if path == "exp4":
        bg_idx = rng.choice(len(Xtr), 200, replace=False)
    te_idx = rng.choice(len(Xte), 500, replace=False)
    return te_idx

rng = np.random.default_rng(SEED)
bg_idx = rng.choice(len(Xtr), 200, replace=False)
background = torch.tensor(Xtr[bg_idx])
subsets = {"exp4": conf_subset("exp4"), "exp5": conf_subset("exp5")}
print("subset overlap (records in both):", len(np.intersect1d(subsets["exp4"], subsets["exp5"])))

def shap_class1(expl, X):
    sv = np.array(expl.shap_values(torch.tensor(X)))
    if sv.ndim == 3:
        if sv.shape[-1] == 2: return sv[:, :, 1]
        if sv.shape[0] == 2: return sv[1]
    return sv

feats = {}
for key, idx in subsets.items():
    Xs = Xu[idx]; ys = yte[idx]
    Xs_adv = pgd(base, Xs, ys, 0.1, mask)
    np.random.seed(SEED); torch.manual_seed(SEED)
    expl = shap.GradientExplainer(base, background)
    sv_c = shap_class1(expl, Xs); sv_a = shap_class1(expl, Xs_adv)
    feats[key] = dict(raw=np.vstack([Xs, Xs_adv]), shap=np.vstack([sv_c, sv_a]))
yv = np.r_[np.zeros(500), np.ones(500)]

def conf_auc(F, rs=SEED, C=None):
    a, b, c, e = train_test_split(F, yv, test_size=0.4, random_state=rs, stratify=yv)
    clf = LogisticRegression(max_iter=2000) if C is None else LogisticRegression(max_iter=2000, C=C)
    clf.fit(a, c); p = clf.predict_proba(b)[:, 1]
    return roc_auc_score(e, p), e, p

audit = {}
for key in subsets:
    for fs in ("raw", "shap"):
        auc, e, p = conf_auc(feats[key][fs])
        _, lo, hi = auc_ci(e, p)
        reps = np.array([conf_auc(feats[key][fs], rs=r)[0] for r in range(200)])
        audit[f"{key}_{fs}"] = dict(auc_conference_split=auc, delong_lo=lo, delong_hi=hi,
                                   rep_mean=float(reps.mean()), rep_std=float(reps.std(ddof=1)),
                                   rep_p2_5=float(np.percentile(reps, 2.5)), rep_p97_5=float(np.percentile(reps, 97.5)))
        print(f"{key} {fs:4s}: AUC(conference split)={auc:.4f} DeLong95%=[{lo:.4f},{hi:.4f}] "
              f"200 splits mean={reps.mean():.4f} sd={reps.std(ddof=1):.4f}", flush=True)

# between-subset variability: 30 independent 500-record subsets (same estimator, class-1 logit)
var_raw, var_shap = [], []
for s in range(30):
    idx = np.random.default_rng(1000 + s).choice(len(Xte), 500, replace=False)
    Xs = Xu[idx]; ys = yte[idx]; Xa = pgd(base, Xs, ys, 0.1, mask)
    var_raw.append(conf_auc(np.vstack([Xs, Xa]))[0])
    phi = eg_attrib(base, np.vstack([Xs, Xa]), Xtr[bg_idx], K=200, target=1, seed=s)
    var_shap.append(conf_auc(phi)[0])
audit["between_subsets_raw"] = dict(mean=float(np.mean(var_raw)), sd=float(np.std(var_raw, ddof=1)),
                                    min=float(np.min(var_raw)), max=float(np.max(var_raw)))
audit["between_subsets_shap"] = dict(mean=float(np.mean(var_shap)), sd=float(np.std(var_shap, ddof=1)),
                                     min=float(np.min(var_shap)), max=float(np.max(var_shap)))
print("between-subset raw :", audit["between_subsets_raw"])
print("between-subset shap:", audit["between_subsets_shap"])
out["auc_audit"] = audit
save_json(out, "e02_conference_reproduction.json")
print("done", round(time.time() - t0, 1), "s")
