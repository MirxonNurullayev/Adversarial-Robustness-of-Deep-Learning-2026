"""
nidslib - shared code for the extended (journal) study:
"Adversarial robustness of deep-learning network intrusion detection:
 two-sided error analysis and an explainability-guided tandem defense".

Everything is deterministic given the seed (CPU, single thread).
"""
import os, json, math, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.nn.functional as F
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder, FunctionTransformer, StandardScaler
from sklearn.linear_model import LogisticRegression
from scipy import stats

torch.set_num_threads(1)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
ART = os.path.join(ROOT, "artifacts")
RES = os.path.join(ROOT, "results")
for _d in (ART, RES):
    os.makedirs(_d, exist_ok=True)

SEEDS = [42, 101, 202, 303, 404]
EPS_GRID = [0.01, 0.02, 0.05, 0.1, 0.2, 0.3]

NSL_COLS = ["duration","protocol_type","service","flag","src_bytes","dst_bytes","land",
    "wrong_fragment","urgent","hot","num_failed_logins","logged_in","num_compromised",
    "root_shell","su_attempted","num_root","num_file_creations","num_shells",
    "num_access_files","num_outbound_cmds","is_host_login","is_guest_login","count",
    "srv_count","serror_rate","srv_serror_rate","rerror_rate","srv_rerror_rate",
    "same_srv_rate","diff_srv_rate","srv_diff_host_rate","dst_host_count",
    "dst_host_srv_count","dst_host_same_srv_rate","dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate","dst_host_srv_diff_host_rate","dst_host_serror_rate",
    "dst_host_srv_serror_rate","dst_host_rerror_rate","dst_host_srv_rerror_rate",
    "label","difficulty"]
NSL_CAT = ["protocol_type", "service", "flag"]
UNSW_CAT = ["proto", "service", "state"]


def save_json(obj, name):
    def conv(o):
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, np.ndarray): return o.tolist()
        raise TypeError(type(o))
    with open(os.path.join(RES, name), "w") as f:
        json.dump(obj, f, indent=1, default=conv)


def load_json(name):
    with open(os.path.join(RES, name)) as f:
        return json.load(f)


# ------------------------------------------------------------------ data
def _read_nsl(path):
    df = pd.read_csv(path, names=NSL_COLS).drop(columns=["difficulty"])
    y = (df["label"].values != "normal").astype(np.int64)
    return df.drop(columns=["label"]), y, df["label"].values


def _read_unsw(path):
    df = pd.read_csv(path)
    df.columns = [c.replace("﻿", "") for c in df.columns]
    y = df["label"].values.astype(np.int64)
    return df.drop(columns=["id", "attack_cat", "label"]), y, df["attack_cat"].values


def prepare(name, base, log, clip=True):
    """Build the encoded feature matrices.
    base: 'nsl' or 'unsw'; log: apply log1p before min-max scaling of numeric features."""
    if base == "nsl":
        Xtr, ytr, atr = _read_nsl(os.path.join(DATA, "KDDTrain.txt"))
        Xte, yte, ate = _read_nsl(os.path.join(DATA, "KDDTest.txt"))
        cat = NSL_CAT
    else:
        Xtr, ytr, atr = _read_unsw(os.path.join(DATA, "UNSW_NB15_training-set.csv"))
        Xte, yte, ate = _read_unsw(os.path.join(DATA, "UNSW_NB15_testing-set.csv"))
        cat = UNSW_CAT
    num = [c for c in Xtr.columns if c not in cat]
    if log:
        assert (Xtr[num].values >= 0).all() and (Xte[num].values >= 0).all()
        numtf = Pipeline([("log", FunctionTransformer(np.log1p, validate=False)), ("mm", MinMaxScaler())])
    else:
        numtf = MinMaxScaler()            # identical to the conference pipeline
    pre = ColumnTransformer([("num", numtf, num),
                             ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat)],
                            remainder="drop")
    Xtr_p = pre.fit_transform(Xtr).astype(np.float32)
    Xte_u = pre.transform(Xte).astype(np.float32)
    n_num = len(num)
    oor_rec = int(((Xte_u[:, :n_num] < 0) | (Xte_u[:, :n_num] > 1)).any(1).sum())
    oor_val = int(((Xte_u[:, :n_num] < 0) | (Xte_u[:, :n_num] > 1)).sum())
    Xte_p = Xte_u.copy()
    if clip:
        Xte_p[:, :n_num] = np.clip(Xte_p[:, :n_num], 0.0, 1.0)
    names = num + list(pre.named_transformers_["cat"].get_feature_names_out(cat))
    ftype = []
    for c in num:
        v = Xtr[c].values.astype(np.float64)
        u = np.unique(v)
        if np.isin(u, [0.0, 1.0]).all():
            ftype.append("binary")
        elif np.all(np.mod(v, 1.0) == 0.0):
            ftype.append("integer")
        else:
            ftype.append("continuous")
    d = Xtr_p.shape[1]
    mask_num = np.zeros(d, np.float32); mask_num[:n_num] = 1.0
    mask_strict = mask_num.copy()
    for j, t in enumerate(ftype):
        if t == "binary":
            mask_strict[j] = 0.0
    mask_all = np.ones(d, np.float32)
    mm = pre.named_transformers_["num"]
    mm = mm.named_steps["mm"] if log else mm
    np.savez_compressed(os.path.join(ART, f"{name}.npz"),
        Xtr=Xtr_p, ytr=ytr, Xte=Xte_p, yte=yte, Xte_unclipped=Xte_u,
        mask_num=mask_num, mask_strict=mask_strict, mask_all=mask_all,
        int_dims=np.array([j for j, t in enumerate(ftype) if t == "integer"], dtype=np.int64),
        data_min=mm.data_min_.astype(np.float64), data_range=mm.data_range_.astype(np.float64),
        log=np.int64(log), n_num=np.int64(n_num), ate=np.asarray(ate).astype(str), atr=np.asarray(atr).astype(str))
    meta = dict(name=name, base=base, log=bool(log), dim=int(d), n_num=n_num, n_onehot=int(d - n_num),
                n_train=int(len(ytr)), n_test=int(len(yte)),
                train_normal=int((ytr == 0).sum()), train_attack=int((ytr == 1).sum()),
                test_normal=int((yte == 0).sum()), test_attack=int((yte == 1).sum()),
                test_records_out_of_range=oor_rec, test_values_out_of_range=oor_val,
                n_binary=ftype.count("binary"), n_integer=ftype.count("integer"),
                n_continuous=ftype.count("continuous"),
                feature_names=names, feature_types=ftype, categorical=cat)
    with open(os.path.join(ART, f"{name}_meta.json"), "w") as f:
        json.dump(meta, f, indent=1)
    return meta


def load(name):
    z = np.load(os.path.join(ART, f"{name}.npz"), allow_pickle=False)
    D = {k: z[k] for k in z.files}
    with open(os.path.join(ART, f"{name}_meta.json")) as f:
        D["meta"] = json.load(f)
    return D


def project_integer(Xadv, X0, eps, D):
    """Strict feasibility projection: integer-valued features are moved to an integer
    value inside the eps-ball around the clean value; if none exists the clean value is kept."""
    Z = Xadv.copy()
    J = D["int_dims"]
    if len(J) == 0:
        return Z
    rng = D["data_range"][J]; mn = D["data_min"][J]; lg = bool(D["log"])
    def to_raw(z):
        r = z * rng + mn
        return np.expm1(r) if lg else r
    def to_z(r):
        r2 = np.log1p(np.clip(r, 0, None)) if lg else r
        return np.where(rng > 0, (r2 - mn) / np.where(rng > 0, rng, 1.0), 0.0)
    za = Z[:, J].astype(np.float64); z0 = X0[:, J].astype(np.float64)
    e = np.broadcast_to(np.asarray(eps, np.float64).reshape(-1, 1) if np.ndim(eps) else float(eps), za.shape)
    raw = to_raw(za)
    cands = [to_z(np.floor(raw)), to_z(np.ceil(raw))]
    best = z0.copy(); bestd = np.full(za.shape, np.inf)
    for c in cands:
        ok = (np.abs(c - z0) <= e + 1e-7) & (c >= -1e-9) & (c <= 1 + 1e-9)
        dist = np.abs(c - za)
        upd = ok & (dist < bestd)
        best = np.where(upd, c, best); bestd = np.where(upd, dist, bestd)
    Z[:, J] = np.clip(best, 0, 1).astype(np.float32)
    return Z


# ------------------------------------------------------------------ model
class DNN(nn.Module):
    def __init__(self, d, h=(128, 64, 32)):
        super().__init__()
        layers, prev = [], d
        for u in h:
            layers += [nn.Linear(prev, u), nn.ReLU(), nn.Dropout(0.3)]; prev = u
        layers += [nn.Linear(prev, 2)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

    def hidden(self, x):
        """Post-ReLU activations of the three hidden layers and the logits (eval mode)."""
        acts = []
        for m in self.net:
            x = m(x)
            if isinstance(m, nn.ReLU):
                acts.append(x)
        acts.append(x)
        return acts


def save_model(model, name):
    torch.save(model.state_dict(), os.path.join(ART, name + ".pt"))


def load_model(name, d):
    m = DNN(d); m.load_state_dict(torch.load(os.path.join(ART, name + ".pt"))); m.eval()
    return m


def model_exists(name):
    return os.path.exists(os.path.join(ART, name + ".pt"))


def train_standard(X, y, seed, epochs=30, bs=512, lr=1e-3, wd=1e-5, tag="std"):
    np.random.seed(seed); torch.manual_seed(seed)
    model = DNN(X.shape[1])
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    lossf = nn.CrossEntropyLoss()
    Xt = torch.tensor(X); yt = torch.tensor(y); n = len(Xt)
    for ep in range(epochs):
        model.train(); perm = torch.randperm(n); tot = 0.0
        for i in range(0, n, bs):
            idx = perm[i:i + bs]; xb = Xt[idx]; yb = yt[idx]
            opt.zero_grad(); loss = lossf(model(xb), yb); loss.backward(); opt.step()
            tot += loss.item() * len(idx)
        if (ep + 1) % 10 == 0:
            print(f"  [{tag} seed={seed}] epoch {ep+1}/{epochs} loss={tot/n:.4f}", flush=True)
    model.eval()
    return model


def train_robust(X, y, mask, seed, method="pgdat", eps=0.1, steps=7, epochs=15, bs=512, lr=1e-3,
                 wd=1e-5, beta=6.0, tag=None):
    """Adversarial training. Inner maximisation: masked L_inf PGD with the network in
    training mode (dropout active), exactly as in the conference implementation.
    method: 'pgdat' (Madry et al.), 'trades' (Zhang et al.), 'mart' (Wang et al.)."""
    tag = tag or method
    np.random.seed(seed); torch.manual_seed(seed)
    model = DNN(X.shape[1])
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    lossf = nn.CrossEntropyLoss()
    m = torch.tensor(mask)
    alpha = 2.5 * eps / steps
    Xt = torch.tensor(X); yt = torch.tensor(y); n = len(Xt)
    kl_sum = nn.KLDivLoss(reduction="sum")
    for ep in range(epochs):
        model.train(); perm = torch.randperm(n); tot = 0.0
        for i in range(0, n, bs):
            idx = perm[i:i + bs]; xb = Xt[idx]; yb = yt[idx]
            if method == "pgdat":
                x0 = xb; x = x0.clone()
                for _ in range(steps):
                    x.requires_grad_(True)
                    loss = lossf(model(x), yb); model.zero_grad(); loss.backward()
                    x = x + alpha * m * x.grad.sign()
                    x = torch.max(torch.min(x, x0 + eps), x0 - eps); x = torch.clamp(x, 0, 1).detach()
                model.train(); opt.zero_grad()
                loss = lossf(model(x), yb)
            elif method == "trades":
                with torch.no_grad():
                    p_nat = F.softmax(model(xb), 1)
                x = torch.clamp(xb + 0.001 * torch.randn(xb.shape) * m, 0, 1).detach()
                for _ in range(steps):
                    x.requires_grad_(True)
                    lk = kl_sum(F.log_softmax(model(x), 1), p_nat)
                    g, = torch.autograd.grad(lk, x)
                    x = x.detach() + alpha * m * g.sign()
                    x = torch.max(torch.min(x, xb + eps), xb - eps).clamp(0, 1)
                opt.zero_grad()
                lo_nat = model(xb)
                loss = F.cross_entropy(lo_nat, yb) + beta * (1.0 / len(xb)) * kl_sum(
                    F.log_softmax(model(x), 1), F.softmax(lo_nat, 1))
            elif method == "mart":
                x = torch.clamp(xb + 0.001 * torch.randn(xb.shape) * m, 0, 1).detach()
                for _ in range(steps):
                    x.requires_grad_(True)
                    g, = torch.autograd.grad(F.cross_entropy(model(x), yb), x)
                    x = x.detach() + alpha * m * g.sign()
                    x = torch.max(torch.min(x, xb + eps), xb - eps).clamp(0, 1)
                opt.zero_grad()
                lo_nat = model(xb); lo_adv = model(x)
                p_adv = F.softmax(lo_adv, 1)
                top2 = torch.argsort(p_adv, 1)[:, -2:]
                new_y = torch.where(top2[:, -1] == yb, top2[:, -2], top2[:, -1])
                l_adv = F.cross_entropy(lo_adv, yb) + F.nll_loss(torch.log(1.0001 - p_adv + 1e-12), new_y)
                # KL(p_nat || p_adv) is evaluated from log-probabilities (log_target=True): a natural
                # probability that underflows to 0 then contributes 0 instead of 0*log(0) = NaN in the
                # backward pass. Mathematically identical to the reference implementation of MART.
                logp_nat = F.log_softmax(lo_nat, 1); p_nat = logp_nat.exp()
                true_p = torch.gather(p_nat, 1, yb.unsqueeze(1)).squeeze(1)
                l_rob = (1.0 / len(xb)) * torch.sum(
                    torch.sum(F.kl_div(torch.log(p_adv + 1e-12), logp_nat, reduction="none", log_target=True), 1)
                    * (1.0000001 - true_p))
                loss = l_adv + beta * l_rob
            else:
                raise ValueError(method)
            loss.backward(); opt.step(); tot += loss.item() * len(idx)
        if (ep + 1) % 5 == 0:
            print(f"  [{tag} seed={seed} eps={eps}] epoch {ep+1}/{epochs} loss={tot/n:.4f}", flush=True)
    model.eval()
    return model


# ------------------------------------------------------------------ inference / attacks
def logits_np(model, X, bs=65536):
    model.eval(); out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            out.append(model(torch.as_tensor(X[i:i + bs])).numpy())
    return np.vstack(out)


def predict(model, X):
    return logits_np(model, X).argmax(1)


def margin_np(model, X):
    z = logits_np(model, X)
    return z[:, 1] - z[:, 0]


def fgsm(model, X, y, eps, mask):
    model.eval()
    x = torch.tensor(X, requires_grad=True); yb = torch.tensor(y)
    loss = F.cross_entropy(model(x), yb); model.zero_grad(); loss.backward()
    return torch.clamp(x + eps * torch.tensor(mask) * x.grad.sign(), 0, 1).detach().numpy()


def pgd(model, X, y, eps, mask, steps=40, alpha_mult=2.5, rand_init=False, restarts=1,
        target=None, seed=0, chunk=None):
    """Masked L_inf PGD with sign-gradient steps (identical to the conference implementation
    for scalar eps without random init). eps may be a scalar or a per-sample array.
    target: optional array of target labels (then the CE to the target is minimised).
    With restarts>1 the first successful iterate per sample is kept."""
    if chunk is not None and len(X) > chunk:
        e_arr = np.broadcast_to(np.asarray(eps, np.float32), (len(X),))
        outs = []
        for i in range(0, len(X), chunk):
            outs.append(pgd(model, X[i:i + chunk], y[i:i + chunk],
                            eps if np.ndim(eps) == 0 else e_arr[i:i + chunk], mask, steps, alpha_mult,
                            rand_init, restarts, None if target is None else target[i:i + chunk], seed + i))
        return np.vstack(outs)
    model.eval()
    X0 = torch.as_tensor(np.ascontiguousarray(X)); yt = torch.as_tensor(y); n = len(X0)
    mk = torch.as_tensor(mask)
    if np.ndim(eps) == 0:
        e = float(eps); a = alpha_mult * float(eps) / steps
        lo, hi = X0 - e, X0 + e
    else:
        e = torch.as_tensor(np.asarray(eps, np.float32)).view(-1, 1); a = alpha_mult * e / steps
        lo, hi = X0 - e, X0 + e
    tg = None if target is None else torch.as_tensor(target)
    g = torch.Generator().manual_seed(seed)
    best = None; done = torch.zeros(n, dtype=torch.bool)
    for r in range(restarts):
        x = X0.clone()
        if rand_init:
            noise = (2 * torch.rand(X0.shape, generator=g) - 1) * e * mk
            x = torch.clamp(X0 + noise, 0, 1)
        for _ in range(steps):
            x.requires_grad_(True)
            out = model(x)
            loss = F.cross_entropy(out, yt) if tg is None else -F.cross_entropy(out, tg)
            model.zero_grad(); loss.backward()
            x = x + a * mk * x.grad.sign()
            x = torch.max(torch.min(x, hi), lo); x = torch.clamp(x, 0, 1).detach()
        if restarts == 1:
            return x.numpy()
        with torch.no_grad():
            p = model(x).argmax(1)
            succ = (p != yt) if tg is None else (p == tg)
        if best is None:
            best = x.clone()
        upd = succ & ~done
        best[upd] = x[upd]; done |= succ
    return best.numpy()


def random_search(model, X, y, eps, mask, queries=1000, seed=0, chunk=512):
    """Gradient-free L_inf attack: best of `queries` random vertices of the masked eps-box
    (score = margin toward the wrong class). Used only as a gradient-masking sanity check."""
    model.eval(); g = torch.Generator().manual_seed(seed)
    mk = torch.as_tensor(mask).bool(); dm = int(mk.sum())
    out = np.array(X, copy=True)
    with torch.no_grad():
        for i in range(0, len(X), chunk):
            x0 = torch.as_tensor(X[i:i + chunk]); yb = torch.as_tensor(y[i:i + chunk]); c = len(x0)
            sgn = (2 * yb - 1).float()                       # +1 for attack class, -1 for normal
            best = x0.clone(); bests = torch.full((c,), float("inf"))
            for q0 in range(0, queries, 50):
                qn = min(50, queries - q0)
                s = (torch.randint(0, 2, (c, qn, dm), generator=g) * 2 - 1).float()
                xc = x0.unsqueeze(1).repeat(1, qn, 1)
                xc[:, :, mk] = torch.clamp(xc[:, :, mk] + eps * s, 0, 1)
                z = model(xc.view(-1, x0.shape[1])).view(c, qn, 2)
                marg = (z[:, :, 1] - z[:, :, 0]) * sgn.view(-1, 1)    # >0 means still correct
                mv, mi = marg.min(1)
                upd = mv < bests
                best[upd] = xc[upd, mi[upd]]; bests[upd] = mv[upd]
            out[i:i + chunk] = best.numpy()
    return out


# ------------------------------------------------------------------ metrics
def confusion(y, p):
    TP = int(((y == 1) & (p == 1)).sum()); FN = int(((y == 1) & (p == 0)).sum())
    TN = int(((y == 0) & (p == 0)).sum()); FP = int(((y == 0) & (p == 1)).sum())
    return TP, FN, TN, FP


def rates(y, p):
    TP, FN, TN, FP = confusion(y, p); P = TP + FN; N = TN + FP
    tpr = TP / P; fpr = FP / N; acc = (TP + TN) / (P + N)
    prec = TP / (TP + FP) if TP + FP > 0 else float("nan")
    f1 = 2 * prec * tpr / (prec + tpr) if (TP > 0) else 0.0
    return dict(TP=TP, FN=FN, TN=TN, FP=FP, acc=acc, tpr=tpr, fpr=fpr, fnr=1 - tpr, tnr=1 - fpr,
                prec=prec, f1=f1, J=tpr - fpr, bal_acc=(tpr + 1 - fpr) / 2,
                lr_pos=(tpr / fpr) if fpr > 0 else float("inf"),
                lr_neg=((1 - tpr) / (1 - fpr)) if fpr < 1 else float("inf"))


def two_sided(y, p_clean, p_adv):
    r = rates(y, p_adv)
    det = (y == 1) & (p_clean == 1); okn = (y == 0) & (p_clean == 0)
    r["ESR"] = float(((p_adv == 0) & det).sum() / max(int(det.sum()), 1))   # evasion success
    r["FSR"] = float(((p_adv == 1) & okn).sum() / max(int(okn.sum()), 1))   # flooding success
    return r


def ppv(tpr, fpr, pi):
    pi = np.asarray(pi, np.float64)
    return tpr * pi / (tpr * pi + fpr * (1 - pi))


def bootstrap_ci(y, p, fn, B=2000, seed=0):
    rng = np.random.default_rng(seed); n = len(y); v = np.empty(B)
    for b in range(B):
        idx = rng.integers(0, n, n); v[b] = fn(y[idx], p[idx])
    return float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))


def mcnemar(y, pa, pb):
    a = pa == y; b_ = pb == y
    b = int((a & ~b_).sum()); c = int((~a & b_).sum())
    stat = (abs(b - c) - 1) ** 2 / max(b + c, 1)
    return dict(b=b, c=c, chi2=float(stat), p=float(stats.chi2.sf(stat, 1)))


# ---- DeLong (fast implementation of Sun & Xu, 2014)
def _midrank(x):
    J = np.argsort(x, kind="mergesort"); Z = x[J]; N = len(x); T = np.zeros(N); i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1); i = j
    T2 = np.empty(N); T2[J] = T + 1
    return T2


def delong(y, scores_list):
    """AUCs and DeLong covariance for one or more score vectors on the same labels."""
    y = np.asarray(y).astype(int)
    order = np.argsort(-y, kind="mergesort")       # positives first
    m = int(y.sum()); n = len(y) - m
    S = np.vstack([np.asarray(s, np.float64)[order] for s in scores_list])
    k = S.shape[0]
    tx = np.empty((k, m)); ty = np.empty((k, n)); tz = np.empty((k, m + n))
    for r in range(k):
        tx[r] = _midrank(S[r, :m]); ty[r] = _midrank(S[r, m:]); tz[r] = _midrank(S[r])
    aucs = tz[:, :m].sum(1) / m / n - (m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    cov = np.atleast_2d(np.cov(v01)) / m + np.atleast_2d(np.cov(v10)) / n
    return aucs, cov


def auc_ci(y, s):
    a, c = delong(y, [s]); se = math.sqrt(max(c[0, 0], 0))
    return float(a[0]), float(max(0, a[0] - 1.96 * se)), float(min(1, a[0] + 1.96 * se))


def delong_test(y, s1, s2):
    a, c = delong(y, [s1, s2])
    var = c[0, 0] + c[1, 1] - 2 * c[0, 1]
    z = (a[0] - a[1]) / math.sqrt(var) if var > 0 else 0.0
    return dict(auc1=float(a[0]), auc2=float(a[1]), z=float(z), p=float(2 * stats.norm.sf(abs(z))))


# ------------------------------------------------------------------ explanations
def eg_attrib(model, X, B, K=200, target="margin", seed=0, chunk=256):
    """Expected-gradients attributions - the Monte-Carlo estimator implemented by
    shap.GradientExplainer: phi_i(x) = E_{b~B, a~U(0,1)}[(x_i-b_i) * d f(b+a(x-b))/d x_i]."""
    model.eval(); g = torch.Generator().manual_seed(seed)
    Xt = torch.as_tensor(X); Bt = torch.as_tensor(B); n, d = Xt.shape; out = []
    for i in range(0, n, chunk):
        x = Xt[i:i + chunk]; c = len(x)
        idx = torch.randint(0, len(Bt), (c, K), generator=g)
        a = torch.rand(c, K, 1, generator=g)
        b = Bt[idx]
        z = (b + a * (x[:, None, :] - b)).reshape(-1, d).requires_grad_(True)
        o = model(z)
        f = (o[:, 1] - o[:, 0]) if target == "margin" else o[:, int(target)]
        gz, = torch.autograd.grad(f.sum(), z)
        out.append(((x[:, None, :] - b) * gz.view(c, K, d)).mean(1).detach().numpy())
    return np.vstack(out)


def input_gradient(model, X, chunk=4096):
    model.eval(); out = []
    for i in range(0, len(X), chunk):
        x = torch.as_tensor(X[i:i + chunk]).clone().requires_grad_(True)
        o = model(x); g, = torch.autograd.grad((o[:, 1] - o[:, 0]).sum(), x)
        out.append(g.numpy())
    return np.vstack(out)


def hidden_np(model, X, chunk=8192):
    model.eval(); outs = None
    with torch.no_grad():
        for i in range(0, len(X), chunk):
            h = [t.numpy() for t in model.hidden(torch.as_tensor(X[i:i + chunk]))]
            outs = [[a] for a in h] if outs is None else [o + [a] for o, a in zip(outs, h)]
    return [np.vstack(o) for o in outs]


def lr_monitor(F0, F1, C=1.0):
    Xm = np.vstack([F0, F1]); ym = np.r_[np.zeros(len(F0)), np.ones(len(F1))]
    return Pipeline([("sc", StandardScaler()), ("lr", LogisticRegression(max_iter=5000, C=C))]).fit(Xm, ym)


def stratified_idx(y, n, seed):
    rng = np.random.default_rng(seed)
    idx = []
    for c in (0, 1):
        pool = np.where(y == c)[0]
        k = int(round(n * len(pool) / len(y)))
        idx.append(rng.choice(pool, k, replace=False))
    return np.sort(np.concatenate(idx))
