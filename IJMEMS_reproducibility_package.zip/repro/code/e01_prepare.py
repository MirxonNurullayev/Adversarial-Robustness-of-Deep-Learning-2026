"""E01: build encoded datasets (main + preprocessing-ablation variants)."""
import json, numpy as np
from nidslib import prepare, ART

variants = [("nsl", "nsl", False), ("nsl_log", "nsl", True), ("unsw", "unsw", True), ("unsw_lin", "unsw", False)]
for name, base, log in variants:
    m = prepare(name, base, log)
    keep = {k: v for k, v in m.items() if k not in ("feature_names", "feature_types")}
    print(name, json.dumps(keep))
