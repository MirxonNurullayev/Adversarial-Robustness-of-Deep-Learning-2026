"""E11: share of missed NSL-KDD attacks that belong to attack types absent from the training partition
(clean test set, undefended and PGD-AT detectors, all five seeds).  usage: python3 e11_novel_types.py"""
import numpy as np
from nidslib import *

D = load("nsl"); Xte, yte = D["Xte"], D["yte"]
z = np.load(os.path.join(os.path.dirname(RES), "artifacts", "nsl.npz"), allow_pickle=True)
ate, atr = z["ate"], z["atr"]
novel = np.isin(ate, np.unique(atr), invert=True) & (yte == 1)
known = ~np.isin(ate, np.unique(atr), invert=True) & (yte == 1)
res = {"n_attack": int((yte == 1).sum()), "n_novel": int(novel.sum()),
       "novel_types": sorted(set(ate[novel].tolist())), "runs": {}}
for kind in ("base", "pgdat"):
    for s in SEEDS:
        nm = f"nsl_{kind}_s{s}"
        if not model_exists(nm):
            continue
        p = predict(load_model(nm, Xte.shape[1]), Xte)
        miss = (yte == 1) & (p == 0)
        res["runs"][nm] = {"tpr_novel": float(p[novel].mean()), "tpr_known": float(p[known].mean()),
                           "share_of_misses_novel": float((miss & novel).sum() / miss.sum()), "n_miss": int(miss.sum())}
        print(nm, res["runs"][nm], flush=True)
save_json(res, "e11_nsl_novel_types.json")
