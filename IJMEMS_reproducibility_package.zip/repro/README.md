# Two-sided adversarial robustness of DL-based NIDS — reproducibility package

Code and raw results for the IJMEMS manuscript
"Adversarial Robustness of Deep Learning-Based Network Intrusion Detection: Two-Sided Error
Analysis and an Explainability-Guided Tandem Defence".

All experiments run on a CPU with one thread; every random choice is seeded.
On unclipped test data the seed-42 models reproduce the conference version of the study exactly
(identical confusion matrices; see `results/e02_conference_reproduction.json`).

## Environment

```
python 3.13, torch 2.13.0 (CPU), scikit-learn 1.9.1, shap 0.52.0, numpy 2.5.3, pandas 3.0.5,
scipy 1.18.1, matplotlib 3.11.2
pip install -r requirements.txt
```

## Data (place in ./data)

| File | Source |
|---|---|
| KDDTrain.txt, KDDTest.txt | NSL-KDD (KDDTrain+ / KDDTest+), https://raw.githubusercontent.com/defcom17/NSL_KDD/master/ |
| UNSW_NB15_training-set.csv, UNSW_NB15_testing-set.csv | UNSW-NB15 official partitions, https://research.unsw.edu.au/projects/unsw-nb15-dataset |

MD5 checksums of the files used: KDDTrain.txt f5592a95d1d1428348dfa6ca9652a800,
KDDTest.txt 7c6d1b1af246690766394920d6b4c751, UNSW_NB15_training-set.csv
e55caabaa6cd4a8f1c06a227bcfababc, UNSW_NB15_testing-set.csv e0beea40262e46168cdb81476dbc27b4.

## Run order

```
cd code
python3 e01_prepare.py                      # encoded datasets + feature typing + masks
python3 e02_reproduce_conference.py         # seed-42 models, conference numbers, AUC audit (0.997 vs 0.999)
python3 e03_multiseed.py nsl                # 5 seeds: baseline + PGD-AT, FGSM/PGD sweeps, two-sided metrics
python3 e03_multiseed.py unsw
python3 e05_checks_radius.py nsl|unsw       # Prop. 1 check, gradient-masking checks, constraint ablation, radius
python3 e06_explain.py nsl|unsw             # EG-SHAP agreement, convergence, explanation shift, seed stability
python3 e07_monitor_tandem.py nsl|unsw      # monitors vs baselines, tandem defence, adaptive attack
python3 e04_defenses.py nsl                 # PGD-AT eps sweep, TRADES, MART (frontier)
python3 e04_defenses.py unsw quick
python3 e09_preproc_ablation.py             # preprocessing ablation (log vs identity transform)
python3 e10_manda.py nsl|unsw               # MANDA-style NIDS-specific baseline (same protocol as e07)
python3 e11_novel_types.py                  # detection of attack types absent from the NSL-KDD training partition
python3 e08_figures.py                      # all figures (PDF, SVG, 600-dpi PNG)
```

`nidslib.py` contains the shared implementation (preprocessing, model, training, attacks,
metrics, DeLong/McNemar/bootstrap statistics, expected-gradients attributions).
Setting `SMOKE=1` runs e05-e07 on small subsets for a quick functional test.

Numerical note: the KL term of MART is evaluated from log-probabilities (`log_target=True`), which is
mathematically identical to the reference implementation but avoids NaN gradients when a softmax
probability underflows (this happened on UNSW-NB15 with the unprotected formula).

## Results and trained models

`results/*.json` hold every number reported in the manuscript. `artifacts/*.pt` contains all trained models
(the scripts reuse them if present; delete them to retrain from scratch). Run `e01_prepare.py` first to rebuild the
encoded datasets in `artifacts/`. Figures are generated into `figures/`.
